#!/usr/bin/env python3
"""Regenerates the sample datasets (40 rides) in JSON + CSV and seeds data/rides.json.

Run from the project root:  python tools/generate_sample_data.py
Deterministic: same output every time.
"""

import csv
import random
import sys
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from ridesplit import calculator, config  # noqa: E402
from ridesplit.models import Passenger, Ride  # noqa: E402
from ridesplit.storage import RideStore  # noqa: E402

TODAY = date(2026, 11, 26)
rng = random.Random(59)

PEOPLE = ["Aarav", "Diya", "Rohan", "Meera", "Kabir", "Ananya", "Vikram", "Isha",
          "Arjun", "Sneha", "Neha", "Rahul", "Priya", "Karan", "Tara", "Imran",
          "Sana", "Dev", "Nisha", "Zoya"]
ROUTES = {
    "Cab": [("MG Road", "Indiranagar"), ("Koramangala", "Whitefield"), ("HSR Layout", "Electronic City"),
            ("Campus Gate 2", "City Mall"), ("Central Station", "Tech Park")],
    "Auto": [("Hostel Block B", "Main Library"), ("Bus Stand", "Hostel Block B"), ("Market Road", "Campus Gate 1")],
    "Carpool": [("Campus Gate 1", "Tech Park"), ("Sector 21", "Sector 62"), ("Whitefield", "MG Road")],
    "Airport": [("Campus Gate 1", "Airport T1"), ("Koramangala", "Airport T2"), ("Airport T1", "Hostel Block B")],
    "Intercity": [("Bengaluru", "Mysuru"), ("Pune", "Mumbai"), ("Chennai", "Pondicherry")],
    "Bike": [("Library", "Canteen"), ("Metro Station", "Campus Gate 2")],
    "Other": [("Event Hall", "Railway Station")],
}
FARE_RANGE = {"Cab": (180, 900), "Auto": (40, 160), "Carpool": (120, 500),
              "Airport": (650, 1800), "Intercity": (2200, 4800), "Bike": (30, 90), "Other": (150, 400)}
NOTES = ["", "", "", "Late night ride", "Rain surge pricing", "Toll included", "Exam day", "Fest weekend",
         "Driver waited 10 min"]

rides: list[Ride] = []


def add(d, cat, origin, dest, total, names, method="equal", values=None,
        status=None, due=None, note=""):
    total = Decimal(str(total)).quantize(Decimal("0.01"))
    vals = [Decimal(str(v)) for v in values] if values else None
    shares = calculator.compute_shares(total, method, len(names), vals)
    if status is None:
        status = "settled" if (TODAY - d).days > 14 else "pending"
    if status == "pending" and due is None:
        due = d + timedelta(days=7)
    rides.append(Ride(
        id=f"R{len(rides) + 1:03d}", date=d.isoformat(), origin=origin, destination=dest,
        category=cat_check(cat), total=total, method=method,
        passengers=[Passenger(n, s) for n, s in zip(names, shares)],
        status=status, due_date=due.isoformat() if (status == "pending" and due) else None,
        note=note).validate())


def cat_check(c):
    assert c in config.CATEGORIES
    return c


# ---- 32 random "normal" rides across June-November 2026 -----------------
days = sorted(rng.sample(range(0, 170), 32))
for offset in days:
    d = date(2026, 6, 5) + timedelta(days=offset)
    cat = rng.choices(list(ROUTES), weights=[8, 6, 5, 4, 2, 3, 1])[0]
    origin, dest = rng.choice(ROUTES[cat])
    lo, hi = FARE_RANGE[cat]
    total = Decimal(rng.randint(lo * 100, hi * 100)) / 100
    k = rng.randint(2, 5 if cat != "Auto" else 3)
    names = rng.sample(PEOPLE, k)
    method = rng.choices(config.METHODS, weights=[6, 2, 1, 2])[0]
    values = None
    if method == "percent":
        cuts = sorted(rng.sample(range(10, 90, 5), k - 1))
        parts = [b - a for a, b in zip([0] + cuts, cuts + [100])]
        values = parts
    elif method == "exact":
        base = calculator.split_equal(total, k)
        values = list(base)
        shift = Decimal("10.00") if total > 60 else Decimal("1.00")
        values[0] += shift
        values[-1] -= shift
    elif method == "weights":
        values = [rng.choice([1, 1.5, 2, 3]) for _ in range(k)]
    add(d, cat, origin, dest, total, names, method, values, note=rng.choice(NOTES))

# ---- hand-made boundary / edge cases ------------------------------------
add(date(2026, 8, 14), "Bike", "Library", "Canteen", "1.00", ["Aarav", "Diya"],
    note="Minimum fare: Rs 1.00 splits 0.50 / 0.50")
add(date(2026, 9, 2), "Cab", "MG Road", "Indiranagar", "100.00", ["Rohan", "Meera", "Kabir"],
    note="100 / 3 -> 33.34 + 33.33 + 33.33 (remainder paisa assigned)")
add(date(2026, 9, 9), "Intercity", "Bengaluru", "Mysuru", "4999.99", ["Isha", "Arjun", "Sneha"],
    note="Just under the high-fare threshold")
add(date(2026, 9, 21), "Other", "Event Hall", "Railway Station", "6000.00",
    ["Aarav", "Diya", "Rohan", "Meera", "Kabir", "Ananya", "Vikram", "Isha", "Arjun", "Sneha", "Neha", "Rahul"],
    note="Maximum group: 12 passengers")
add(date(2026, 10, 3), "Intercity", "Pune", "Mumbai", "25000.00", ["Priya", "Karan"],
    "exact", ["15000.00", "10000.00"], status="settled", note="Very large fare (triggers high-fare warning)")
add(date(2026, 10, 11), "Cab", "Koramangala", "Whitefield", "840.00", ["Tara", "Imran", "Sana"],
    "percent", [80, 10, 10], status="settled", note="One person pays 80%")
add(date(2026, 10, 18), "Airport", "Campus Gate 1", "Airport T1", "1500.00", ["Dev", "Nisha"],
    status="pending", due=date(2026, 10, 25), note="Overdue payment demo")
add(date(2026, 11, 5), "Cab", "HSR Layout", "Electronic City", "612.50", ["Zoya", "Aarav", "Meera"],
    "weights", [2, 1, 1], status="pending", due=date(2026, 11, 12), note="Overdue payment demo (2:1:1)")
add(date(2026, 11, 22), "Auto", "Market Road", "Campus Gate 1", "135.00", ["Rohan", "Kabir"],
    status="pending", due=date(2026, 11, 27), note="Due tomorrow")
add(date(2026, 11, 24), "Carpool", "Sector 21", "Sector 62", "320.00", ["Ananya", "Vikram", "Isha", "Arjun"],
    status="pending", due=date(2026, 11, 28), note="Due in 2 days")
# deliberate duplicate to demo the duplicate warning
add(date(2026, 11, 24), "Carpool", "Sector 21", "Sector 62", "320.00", ["Ananya", "Vikram", "Isha", "Arjun"],
    status="pending", due=date(2026, 12, 1), note="Entered twice by mistake")

assert len(rides) == 43, len(rides)
rides.sort(key=lambda r: (r.date, r.id))
for i, r in enumerate(rides, 1):
    r.id = f"R{i:03d}"
    r.validate()

# ---- write outputs ---------------------------------------------------------
sample_dir = ROOT / "sample_data"
sample_dir.mkdir(exist_ok=True)
store = RideStore(sample_dir / "sample_rides.json")
store.rides = rides
store.save()

with open(sample_dir / "sample_rides.csv", "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh)
    w.writerow(["date", "origin", "destination", "category", "total", "passengers",
                "method", "shares", "status", "due_date", "note"])
    for r in rides:
        # unequal rides are written as exact amounts so the CSV round-trips losslessly
        method = "equal" if r.method == "equal" else "exact"
        shares = "" if method == "equal" else ";".join(f"{p.share:.2f}" for p in r.passengers)
        w.writerow([r.date, r.origin, r.destination, r.category, f"{r.total:.2f}",
                    ";".join(r.passenger_names), method, shares,
                    r.status, r.due_date or "", r.note])

seed = RideStore(ROOT / "data" / "rides.json")
seed.rides = rides
seed.save()
print(f"Wrote {len(rides)} rides to sample_data/ and data/rides.json")
