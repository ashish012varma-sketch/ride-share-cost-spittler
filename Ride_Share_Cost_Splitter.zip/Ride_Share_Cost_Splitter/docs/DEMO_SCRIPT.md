# 5-minute demo script (follows section 9 of the brief)

Practice once with `python main.py --no-color` if your terminal shows odd colours.
Before presenting, reset to a known state: delete `data/rides.json`, run `python main.py`,
choose `10` (Load sample dataset), then `0`.

| Min | Do this | Say / point out |
|---|---|---|
| 0:00 | `python main.py` | Branded banner, "43 rides loaded" and a **warnings found** badge (the count depends on today's date, because overdue is measured against it). Zero dependencies. |
| 0:30 | **1 Add ride** - date `2030-01-01` (rejected: future) -> any recent past date (or just press Enter for today); pickup `x` (rejected); total `abc`, then `-50`, then `0.5`, then `1000`; passengers `1` (rejected) -> `3`; names `Aarav`, `aarav` (duplicate rejected), `Diya`, `Rohan` | "Validation catches and corrects every bad input and just asks again - nothing crashes." |
| 1:30 | Split method `2` (percentage): `150` (rejected), then `50`, `30`, blank | Unequal shares; blank takes the remaining %. Show the review table: shares add up to the paisa. Save `y`. |
| 2:15 | **3 Search** - keyword `airport`; then category `Cab` + status `pending` | Keyword + category filtering, AND logic, match total. |
| 2:45 | **6 Executive summary** | Totals, average/median, settled vs pending vs overdue, category table + bars, monthly trend, who owes what. |
| 3:30 | **7 Warnings** | Overdue (red), due soon, high fare, duplicate ride. Then **4** settle an overdue ride. |
| 4:00 | **0 Exit**, relaunch `python main.py` | "Persistence": the new ride and the status change are still there ("44 rides loaded"). |
| 4:20 | **8 Export -> All three**, then **5 Chart** | Open `reports/` : Markdown report, audit log, CSV, PNG. |
| 4:45 | **9 Import** (press Enter for default file) | With the sample data already loaded: 7 added, 1 duplicate skipped, 9 rejected - each with a line-by-line reason and a log file. |
| 5:00 | Show `python -m unittest discover -s tests -t .` -> `OK` | "50 automated tests." |

Backup plan: if anything goes wrong, `10` reloads the sample data (a backup copy is kept).
