"""Import / export / end-to-end menu tests (input is scripted, like the live demo)."""

import builtins
import contextlib
import io
import tempfile
import unittest
from datetime import date
from decimal import Decimal as D
from pathlib import Path
from unittest import mock

from ridesplit import config, exporter, importer, ui
from ridesplit.app import App
from ridesplit.storage import RideStore
from ridesplit.summary import compute_summary

TODAY = date(2026, 11, 26)
ROOT = Path(__file__).resolve().parent.parent


def run_app(path, inputs):
    """Run the real menu loop with scripted keyboard input; returns captured stdout."""
    ui.setup_console(color=False)
    feed = iter(inputs)

    def fake_input(prompt=""):
        try:
            value = next(feed)
        except StopIteration:
            raise EOFError
        print(f"{prompt}{value}")          # echo like a terminal
        return value

    out = io.StringIO()
    with mock.patch.object(builtins, "input", fake_input), contextlib.redirect_stdout(out):
        App(RideStore(path), today=lambda: TODAY).start()
    return out.getvalue()


class ImportTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)
        self.store = RideStore(self.dir / "rides.json")
        self.store.load()

    def tearDown(self):
        self.tmp.cleanup()

    def test_legacy_sample(self):
        res = importer.import_csv(config.LEGACY_CSV, self.store, log_dir=self.dir)
        self.assertIsNone(res.fatal)
        self.assertEqual(res.added, 8)
        self.assertEqual(res.rejected, 9)
        self.assertEqual(res.rows_read, 17)
        joined = "\n".join(res.errors)
        for needle in ("total:", "date:", "category:", "passengers:", "shares:"):
            self.assertIn(needle, joined)
        self.assertTrue(res.log_path and res.log_path.exists())
        reloaded = RideStore(self.store.path)
        reloaded.load()
        self.assertEqual(len(reloaded.rides), 8)              # persisted
        for r in reloaded.rides:                              # shares always reconcile
            self.assertEqual(sum(p.share for p in r.passengers), r.total)

    def test_reimport_skips_duplicates(self):
        importer.import_csv(config.LEGACY_CSV, self.store, log_dir=self.dir)
        again = importer.import_csv(config.LEGACY_CSV, self.store, log_dir=self.dir)
        self.assertEqual(again.added, 0)
        self.assertEqual(again.duplicates, 8)

    def test_missing_file(self):
        res = importer.import_csv(self.dir / "nope.csv", self.store, log_dir=self.dir)
        self.assertIn("not found", res.fatal)

    def test_bad_header_and_empty(self):
        bad = self.dir / "bad.csv"
        bad.write_text("date,origin\n2026-01-01,X\n", encoding="utf-8")
        self.assertIn("Missing required", importer.import_csv(bad, self.store, log_dir=self.dir).fatal)
        empty = self.dir / "empty.csv"
        empty.write_text("", encoding="utf-8")
        self.assertIn("empty", importer.import_csv(empty, self.store, log_dir=self.dir).fatal)

    def test_binary_file(self):
        junk = self.dir / "junk.csv"
        junk.write_bytes(b"\xff\xfe\x00\x01\x02")
        res = importer.import_csv(junk, self.store, log_dir=self.dir)
        self.assertTrue(res.fatal or res.rejected or res.rows_read == 0)

    def test_sample_csv_round_trips(self):
        res = importer.import_csv(ROOT / "sample_data" / "sample_rides.csv", self.store, log_dir=self.dir)
        self.assertEqual(res.rejected, 0, res.errors)
        self.assertEqual(res.added, 42)          # the deliberate duplicate row is skipped
        self.assertEqual(res.duplicates, 1)


class ExportTests(unittest.TestCase):
    def test_all_formats(self):
        store = RideStore(ROOT / "sample_data" / "sample_rides.json")
        store.load()
        summary = compute_summary(store.rides, TODAY)
        with tempfile.TemporaryDirectory() as d:
            paths = exporter.export_all(store.rides, summary, d)
            self.assertEqual({p.suffix for p in paths}, {".md", ".txt", ".csv"})
            md = paths[0].read_text(encoding="utf-8")
            self.assertIn("## Spending by category", md)
            self.assertIn("## Warnings", md)
            audit = paths[1].read_text(encoding="utf-8")
            self.assertNotIn("MISMATCH", audit)
            rows = paths[2].read_text(encoding="utf-8").strip().splitlines()
            self.assertEqual(len(rows) - 1, sum(len(r.passengers) for r in store.rides))


class EndToEndTests(unittest.TestCase):
    """Mirrors the demo: add a ride with bad inputs, quit, relaunch, data is still there."""

    def test_add_validate_persist_relaunch(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "rides.json"
            out = run_app(path, [
                "1",
                "2030-01-01",          # future date -> rejected
                "2026-11-20",
                "x",                   # too-short location -> rejected
                "Campus Gate",
                "Airport T1",
                "banana",              # bad category
                "4",                   # Airport
                "abc", "-50", "0", "1200",      # bad totals then valid
                "1", "9",              # 1 passenger (too few) then...
                "3",
                "R2D2", "Aarav", "aarav", "Diya", "Rohan",   # bad name, duplicate name
                "2",                   # percentage
                "50", "60",            # 60 > remaining? valid number but sum mismatch later
                "",                    # last: blank takes the rest (-10 left -> error path)
            ])
            self.assertIn("[X]", out)                       # validation errors were shown
            self.assertIn("cannot be in the future", out)
            self.assertIn("Total fare must be at least", out)

    def test_full_happy_path_then_relaunch(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "rides.json"
            out = run_app(path, [
                "1", "2026-11-20", "Campus Gate", "Airport T1", "4", "1000", "3",
                "Aarav", "Diya", "Rohan", "1",          # equal split
                "settled", "Late flight", "y",
                "0",
            ])
            self.assertIn("333.34", out)                # remainder paisa to first passenger
            self.assertIn("Saved R001", out)
            out2 = run_app(path, ["2", "", "R001", "", "6", "", "0"])      # relaunch
            self.assertIn("1 ride(s) loaded", out2)
            self.assertIn("Campus Gate -> Airport T1", out2)
            self.assertIn("EXECUTIVE SUMMARY", out2)

    def test_unequal_percent_with_autofill(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "rides.json"
            run_app(path, [
                "1", "2026-11-20", "Hostel", "Library", "2", "250", "3",
                "A", "B", "C", "2",
                "50", "30", "",                         # blank = remaining 20%
                "pending", "2026-11-30", "", "y", "0",
            ])
            store = RideStore(path)
            store.load()
            shares = [p.share for p in store.rides[0].passengers]
            self.assertEqual(shares, [D("125.00"), D("75.00"), D("50.00")])
            self.assertEqual(store.rides[0].due_date, "2026-11-30")

    def test_percent_mismatch_reprompts_instead_of_crashing(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "rides.json"
            out = run_app(path, [
                "1", "2026-11-20", "Hostel", "Library", "2", "100", "2",
                "A", "B", "2",
                "70", "40",                              # 110% -> error, re-enter
                "70", "30",
                "settled", "", "y", "0",
            ])
            self.assertIn("add up to exactly 100", out)
            store = RideStore(path)
            store.load()
            self.assertEqual([p.share for p in store.rides[0].passengers], [D("70.00"), D("30.00")])

    def test_cancel_and_junk_menu_input(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "rides.json"
            out = run_app(path, ["", "abc", "99", "1", "2026-11-20", "!", "0"])
            self.assertIn("Cancelled", out)
            self.assertIn("Please enter a number", out)
            store = RideStore(path)
            store.load()
            self.assertEqual(store.rides, [])

    def test_eof_exits_cleanly(self):
        with tempfile.TemporaryDirectory() as d:
            out = run_app(Path(d) / "rides.json", [])       # stdin closed immediately
            self.assertIn("Goodbye", out)

    def test_load_sample_search_status_delete_export(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "rides.json"
            out = run_app(path, [
                "10",
                "3", "airport", "", "", "", "", "", "", "", "",   # keyword search
                "4", "R034", "y",                                  # settle an overdue ride
                "5", "R043", "y",                                  # delete the duplicate
                "7",
                "0",
            ])
            self.assertIn("Loaded 43 sample rides", out)
            self.assertIn("MATCH(ES)", out)
            self.assertIn("is now settled", out)
            self.assertIn("R043 deleted", out)
            store = RideStore(path)
            store.load()
            self.assertEqual(len(store.rides), 42)
            self.assertEqual(store.get("R034").status, "settled")


if __name__ == "__main__":
    unittest.main()
