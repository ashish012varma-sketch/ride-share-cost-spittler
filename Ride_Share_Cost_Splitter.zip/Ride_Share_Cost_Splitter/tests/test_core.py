import json
import tempfile
import unittest
from datetime import date
from decimal import Decimal as D
from pathlib import Path

from ridesplit import calculator as calc
from ridesplit import validation as v
from ridesplit.alerts import CRITICAL, compute_alerts
from ridesplit.models import Passenger, Ride
from ridesplit.search import Filters, filter_rides
from ridesplit.storage import RideStore
from ridesplit.summary import compute_summary

TODAY = date(2026, 11, 26)


def make_ride(i=1, total="100.00", status="settled", due=None, d="2026-11-01", names=("A", "B"),
              origin="MG Road", dest="Airport", cat="Cab", note=""):
    shares = calc.split_equal(D(total), len(names))
    return Ride(f"R{i:03d}", d, origin, dest, cat, D(total), "equal",
                [Passenger(n, s) for n, s in zip(names, shares)], status, due, note).validate()


class CalculatorTests(unittest.TestCase):
    def test_equal_split_remainder_goes_to_first(self):
        self.assertEqual(calc.split_equal(D("100.00"), 3), [D("33.34"), D("33.33"), D("33.33")])

    def test_equal_always_sums_to_total(self):
        for total in ("0.01", "1.00", "99.99", "100000.00", "4999.99"):
            for n in range(1, 13):
                self.assertEqual(sum(calc.split_equal(D(total), n)), D(total), (total, n))

    def test_percent_split(self):
        self.assertEqual(calc.split_percent(D("200.00"), [D(50), D(30), D(20)]),
                         [D("100.00"), D("60.00"), D("40.00")])

    def test_percent_must_total_100(self):
        with self.assertRaises(v.ValidationError):
            calc.split_percent(D("100"), [D(50), D(30)])

    def test_percent_rounding_still_sums(self):
        shares = calc.split_percent(D("100.01"), [D("33.33"), D("33.33"), D("33.34")])
        self.assertEqual(sum(shares), D("100.01"))

    def test_exact_mismatch_rejected(self):
        with self.assertRaises(v.ValidationError):
            calc.split_exact(D("100"), [D("60"), D("30")])

    def test_exact_ok(self):
        self.assertEqual(calc.split_exact(D("100"), [D("60"), D("40")]), [D("60.00"), D("40.00")])

    def test_weights(self):
        self.assertEqual(calc.split_weighted(D("100.00"), [D(2), D(1), D(1)]),
                         [D("50.00"), D("25.00"), D("25.00")])

    def test_weights_random_sums(self):
        shares = calc.split_weighted(D("1000.01"), [D("1.5"), D(3), D(7), D("0.25")])
        self.assertEqual(sum(shares), D("1000.01"))

    def test_zero_weight_rejected(self):
        with self.assertRaises(v.ValidationError):
            calc.split_weighted(D("10"), [D(1), D(0)])

    def test_compute_shares_needs_values(self):
        with self.assertRaises(v.ValidationError):
            calc.compute_shares(D("10"), "percent", 2, None)

    def test_unknown_method(self):
        with self.assertRaises(v.ValidationError):
            calc.compute_shares(D("10"), "bogus", 2)


class ValidationTests(unittest.TestCase):
    def test_amount_good(self):
        self.assertEqual(v.parse_amount("1,234.5"), D("1234.50"))
        self.assertEqual(v.parse_amount("Rs. 99"), D("99.00"))
        self.assertEqual(v.parse_amount("₹450"), D("450.00"))

    def test_amount_bad(self):
        for bad in ["", "   ", "abc", "-5", "1e5", "nan", "inf", "10.999", "1.2.3", "0x10"]:
            with self.assertRaises(v.ValidationError, msg=bad):
                v.parse_amount(bad)

    def test_total_range(self):
        for bad in ["0", "0.99", "100000.01"]:
            with self.assertRaises(v.ValidationError, msg=bad):
                v.parse_total(bad)
        self.assertEqual(v.parse_total("1"), D("1.00"))
        self.assertEqual(v.parse_total("100000"), D("100000.00"))

    def test_name(self):
        self.assertEqual(v.parse_name("  Mary   Ann "), "Mary Ann")
        for bad in ["", "123", "_x", "A" * 31, "<script>"]:
            with self.assertRaises(v.ValidationError, msg=bad):
                v.parse_name(bad)
        with self.assertRaises(v.ValidationError):
            v.parse_name("aarav", taken=["Aarav"])

    def test_date(self):
        self.assertEqual(v.parse_date("2026-11-20", today=TODAY), "2026-11-20")
        for bad in ["2026-13-01", "20-11-2026", "2026/11/20", "", "2026-02-30", "1999-01-01"]:
            with self.assertRaises(v.ValidationError, msg=bad):
                v.parse_date(bad, today=TODAY)
        with self.assertRaises(v.ValidationError):
            v.parse_date("2026-11-27", today=TODAY)
        self.assertEqual(v.parse_date("2026-11-27", allow_future=True), "2026-11-27")

    def test_due_before_ride(self):
        with self.assertRaises(v.ValidationError):
            v.parse_due_date("2026-01-01", "2026-02-01")

    def test_int(self):
        self.assertEqual(v.parse_int("5", "n", 2, 12), 5)
        for bad in ["1", "13", "abc", "", "2.5", "-3"]:
            with self.assertRaises(v.ValidationError, msg=bad):
                v.parse_int(bad, "n", 2, 12)

    def test_choice(self):
        opts = ("Cab", "Auto", "Carpool")
        self.assertEqual(v.parse_choice("2", opts), "Auto")
        self.assertEqual(v.parse_choice("cab", opts), "Cab")
        self.assertEqual(v.parse_choice("aut", opts), "Auto")
        for bad in ["9", "c", "", "zzz"]:       # "c" is ambiguous (Cab/Carpool)
            with self.assertRaises(v.ValidationError, msg=bad):
                v.parse_choice(bad, opts)

    def test_ride_id(self):
        self.assertEqual(v.parse_ride_id("12"), "R012")
        self.assertEqual(v.parse_ride_id("r7"), "R007")
        with self.assertRaises(v.ValidationError):
            v.parse_ride_id("xyz")


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "data" / "rides.json"

    def tearDown(self):
        self.tmp.cleanup()

    def test_missing_file_created(self):
        store = RideStore(self.path)
        notes = store.load()
        self.assertTrue(self.path.exists())
        self.assertTrue(notes)
        self.assertEqual(store.rides, [])

    def test_roundtrip(self):
        s = RideStore(self.path)
        s.load()
        s.add(make_ride(1, "100.00", names=("A", "B", "C")))
        s2 = RideStore(self.path)
        s2.load()
        self.assertEqual(len(s2.rides), 1)
        self.assertEqual(s2.rides[0].passengers[0].share, D("33.34"))

    def test_corrupt_json_recovers(self):
        self.path.parent.mkdir(parents=True)
        self.path.write_text("{ this is not json", encoding="utf-8")
        store = RideStore(self.path)
        notes = store.load()
        self.assertEqual(store.rides, [])
        self.assertTrue(any("unreadable" in n for n in notes))
        self.assertTrue(list(self.path.parent.glob("*.corrupt-*")))   # evidence preserved
        json.loads(self.path.read_text(encoding="utf-8"))             # clean file now valid

    def test_empty_and_binary_file(self):
        self.path.parent.mkdir(parents=True)
        self.path.write_bytes(b"")
        RideStore(self.path).load()
        self.path.write_bytes(b"\xff\xfe\x00garbage")
        store = RideStore(self.path)
        store.load()
        self.assertEqual(store.rides, [])

    def test_wrong_shape(self):
        self.path.parent.mkdir(parents=True)
        self.path.write_text('{"rides": "nope"}', encoding="utf-8")
        store = RideStore(self.path)
        self.assertTrue(store.load())
        self.assertEqual(store.rides, [])

    def test_bad_records_skipped_good_kept(self):
        good = make_ride(1).to_dict()
        bad = make_ride(2).to_dict()
        bad["total"] = 999.0          # shares no longer add up
        dup = dict(good)
        self.path.parent.mkdir(parents=True)
        self.path.write_text(json.dumps({"rides": [good, bad, dup, 5, {"id": "R9"}]}), encoding="utf-8")
        store = RideStore(self.path)
        notes = store.load()
        self.assertEqual(len(store.rides), 1)
        self.assertGreaterEqual(len(notes), 4)

    def test_next_id_delete_status(self):
        s = RideStore(self.path)
        s.load()
        s.add(make_ride(1))
        s.add(make_ride(5))
        self.assertEqual(s.next_id(), "R006")
        self.assertTrue(s.set_status("R001", "pending"))
        self.assertEqual(s.get("R001").status, "pending")
        self.assertTrue(s.delete("R005"))
        self.assertFalse(s.delete("R999"))


class SearchTests(unittest.TestCase):
    def setUp(self):
        self.rides = [
            make_ride(1, "100.00", d="2026-10-01", names=("Aarav", "Diya"), origin="MG Road", dest="Airport", cat="Airport"),
            make_ride(2, "50.00", status="pending", d="2026-11-01", names=("Rohan", "Meera"), origin="Library",
                      dest="Canteen", cat="Bike", note="Exam day"),
            make_ride(3, "700.00", d="2026-11-10", names=("Aarav", "Kabir"), origin="Mall", dest="Home"),
        ]

    def ids(self, **kw):
        return [r.id for r in filter_rides(self.rides, Filters(**kw))]

    def test_keyword(self):
        self.assertEqual(self.ids(keyword="airport"), ["R001"])
        self.assertEqual(self.ids(keyword="exam"), ["R002"])
        self.assertEqual(self.ids(keyword="AARAV mall"), ["R003"])      # AND, case-insensitive
        self.assertEqual(self.ids(keyword="zzz"), [])

    def test_category_status_person(self):
        self.assertEqual(self.ids(category="Bike"), ["R002"])
        self.assertEqual(self.ids(status="pending"), ["R002"])
        self.assertEqual(self.ids(passenger="aar"), ["R001", "R003"])

    def test_ranges(self):
        self.assertEqual(self.ids(date_from="2026-11-01"), ["R002", "R003"])
        self.assertEqual(self.ids(date_to="2026-10-31"), ["R001"])
        self.assertEqual(self.ids(min_total=D("100"), max_total=D("700")), ["R001", "R003"])

    def test_empty_filter_returns_all(self):
        self.assertEqual(len(self.ids()), 3)
        self.assertTrue(Filters().is_empty())


class SummaryAlertTests(unittest.TestCase):
    def test_empty_summary(self):
        s = compute_summary([], TODAY)
        self.assertEqual(s.count, 0)
        self.assertEqual(s.total, D("0.00"))

    def test_totals_and_status(self):
        rides = [
            make_ride(1, "100.00", d="2026-09-10"),
            make_ride(2, "300.00", status="pending", due="2026-11-01", d="2026-10-20"),
            make_ride(3, "200.00", d="2026-10-05", cat="Auto"),
        ]
        s = compute_summary(rides, TODAY)
        self.assertEqual(s.total, D("600.00"))
        self.assertEqual(s.average, D("200.00"))
        self.assertEqual(s.median, D("200.00"))
        self.assertEqual((s.settled_count, s.pending_count, s.overdue_count), (2, 1, 1))
        self.assertEqual(s.pending_amount, D("300.00"))
        self.assertEqual(s.by_category[0][0], "Cab")
        self.assertIn("UP", s.trend)
        self.assertEqual(sum(p[2] for p in s.people), D("600.00"))

    def test_alerts(self):
        rides = [
            make_ride(1, "100.00", status="pending", due="2026-11-20"),                  # overdue 6d
            make_ride(2, "100.00", status="pending", due="2026-11-27"),                  # due soon
            make_ride(3, "6000.00"),                                                      # high fare
            make_ride(4, "100.00", d="2026-11-02"),
            make_ride(5, "100.00", d="2026-11-02"),                                       # duplicate of 4
        ]
        alerts = compute_alerts(rides, TODAY)
        text = " | ".join(a.message for a in alerts)
        self.assertIn("OVERDUE by 6 days", text)
        self.assertIn("Payment due 2026-11-27", text)
        self.assertIn("High fare", text)
        self.assertIn("duplicate of R004", text)
        self.assertEqual(alerts[0].level, CRITICAL)      # most severe first

    def test_settled_never_overdue(self):
        r = make_ride(1, status="settled", due="2020-01-01", d="2019-12-01")
        self.assertEqual(compute_alerts([r], TODAY), [])


if __name__ == "__main__":
    unittest.main()
