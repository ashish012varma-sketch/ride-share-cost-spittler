# Ride Share Cost Splitter (RideSplit)

Project #59 - FutureReady Hack - Travel & Transport.
A beginner-friendly, **zero-dependency Python 3.10+ terminal app** that divides a shared ride
cost among passengers - equally or unequally - with strict input validation, JSON persistence,
search, an executive summary, warnings and report export.

## Run it

```bash
python main.py                 # data is stored in data/rides.json (pre-seeded with 43 sample rides)
python main.py --no-color      # plain output (e.g. for screen recording issues)
python main.py --data-file my.json
```

No `pip install` needed. (`matplotlib` is optional, only for the PNG chart.)
Run the tests: `python -m unittest discover -s tests -t .`  (50 tests)

## Features -> brief checklist

| Brief requirement | Where |
|---|---|
| Interactive menu-driven terminal UI (ANSI colour, branded banner, paged tables) | `ridesplit/app.py`, `ui.py` |
| Defensive input validation (type, range, format, duplicates, future dates) | `ridesplit/validation.py` |
| Core logic: equal split **and** unequal (percentage / exact amounts / ratio weights), exact to the paisa | `ridesplit/calculator.py` |
| Local persistence in JSON (atomic writes, schema check, self-healing) | `ridesplit/storage.py` |
| Keyword + category/status/passenger/date/amount filtering | `ridesplit/search.py` |
| Executive summary: totals, averages, median, status indicators, monthly trend, who-owes-what | `ridesplit/summary.py` |
| Export to Markdown, plain-text audit log, CSV (+ optional Matplotlib PNG) | `ridesplit/exporter.py`, `charts.py` |
| Threshold warnings: overdue, due soon, high fare, outliers, dominant payer, duplicates | `ridesplit/alerts.py` |
| Bulk CSV import with format validation and row-by-row error log | `ridesplit/importer.py` |
| Sample data: 43 rides (CSV + JSON) incl. boundary/edge cases | `sample_data/` |

Not included (stretch only): Tkinter/Textual GUI.

## Menu

`1` Add ride - `2` View rides - `3` Search - `4` Update payment status - `5` Delete -
`6` Executive summary - `7` Warnings - `8` Export - `9` Import CSV - `10` Load sample data - `0` Exit.
Type `!` at any prompt to cancel without saving.

## How the split works

All money is handled in integer paise (never floats). Leftover paise are given out with the
largest-remainder method, so shares **always add up exactly** to the total:
`Rs 100.00 / 3 -> 33.34 + 33.33 + 33.33`.

* **Equal** - everyone pays the same (remainder paise go to the first passengers).
* **Percentage** - must total exactly 100. The last passenger can be left blank to take the rest.
* **Exact amounts** - must total the fare. The last passenger can be left blank to take the rest.
* **Ratio / weights** - e.g. `2 : 1 : 1`.

## Validation rules

Fare Rs 1.00 - Rs 100,000.00, max 2 decimals, no negatives/NaN/exponents - 2-12 passengers with
unique names (letters, spaces, `. ' -`) - real calendar dates in `YYYY-MM-DD`, not in the future -
due date not before the ride date - category/status/method from fixed lists.
Invalid input never crashes the app: it shows what was wrong and asks again.

## Data files

* `data/rides.json` - live data. If it is missing, empty, corrupt or the wrong shape the app
  keeps a `*.corrupt-<time>.json` copy and starts with a clean file. Individual bad records are
  skipped with a message; good ones still load.
* `sample_data/sample_rides.json|csv` - 43 realistic rides (menu `10` loads them).
* `sample_data/legacy_import_sample.csv` - 17 rows, 9 of them deliberately invalid, to demo
  menu `9` and the error log (written to `reports/import_log_*.txt`).
* `sample_reports/` - example exports (Markdown, audit log, CSV, PNG chart).

## Project layout

```
main.py                 entry point
ridesplit/              application package (one module per concern)
tests/                  unit + end-to-end tests (scripted keyboard input)
sample_data/            sample CSV/JSON + legacy import file with bad rows
sample_reports/         example exports
tools/generate_sample_data.py   regenerates the sample data
docs/                   previous-attempt analysis, demo script
```
