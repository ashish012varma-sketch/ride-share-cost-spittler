#!/usr/bin/env python3
"""Ride Share Cost Splitter - run with:  python main.py"""

import argparse
import sys

if sys.version_info < (3, 10):
    sys.exit("RideSplit needs Python 3.10 or newer.")

from ridesplit import __version__, config, ui
from ridesplit.app import App
from ridesplit.storage import RideStore


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Ride Share Cost Splitter")
    parser.add_argument("--data-file", default=str(config.DATA_FILE),
                        help="JSON file used for persistence (default: data/rides.json)")
    parser.add_argument("--no-color", action="store_true", help="disable ANSI colours")
    parser.add_argument("--version", action="version", version=f"RideSplit {__version__}")
    args = parser.parse_args(argv)

    ui.setup_console(color=False if args.no_color else None)
    try:
        App(RideStore(args.data_file)).start()
    except KeyboardInterrupt:
        print("\nGoodbye!")
    return 0


if __name__ == "__main__":
    sys.exit(main())
