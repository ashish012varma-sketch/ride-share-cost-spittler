"""Bulk import of legacy CSV datasets with row-by-row validation and an error log.

Expected header (order free, case-insensitive):
  required: date, origin, destination, category, total, passengers
  optional: method (equal|percent|exact|weights), shares, status, due_date, note
`passengers` and `shares` are lists separated by ';' (or '|').
"""

from __future__ import annotations

import csv
import io
from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from pathlib import Path

from . import config
from .calculator import compute_shares
from .models import Passenger, Ride
from .storage import RideStore
from .validation import (
    ValidationError,
    clean_text,
    parse_choice,
    parse_date,
    parse_due_date,
    parse_name,
    parse_note,
    parse_place,
    parse_positive_decimal,
    parse_total,
)

REQUIRED = ("date", "origin", "destination", "category", "total", "passengers")
OPTIONAL = ("method", "shares", "status", "due_date", "note")


@dataclass
class ImportResult:
    rows_read: int = 0
    added: int = 0
    duplicates: int = 0
    errors: list[str] = field(default_factory=list)   # "Line 7: ..." strings
    fatal: str | None = None
    log_path: Path | None = None

    @property
    def rejected(self) -> int:
        return len(self.errors)


def _split_list(text: str) -> list[str]:
    sep = "|" if "|" in text and ";" not in text else ";"
    return [clean_text(x) for x in text.split(sep) if clean_text(x)]


def _row_to_ride(row: dict[str, str], ride_id: str) -> Ride:
    """Validate one CSV row. Raises ValidationError('field: reason')."""

    def field_error(name, exc):
        return ValidationError(f"{name}: {exc}")

    try:
        date_ = parse_date(row.get("date"))
    except ValidationError as e:
        raise field_error("date", e)
    try:
        origin = parse_place(row.get("origin"), "Origin")
        destination = parse_place(row.get("destination"), "Destination")
    except ValidationError as e:
        raise field_error("location", e)
    try:
        category = parse_choice(row.get("category"), config.CATEGORIES, "Category")
    except ValidationError as e:
        raise field_error("category", e)
    try:
        total = parse_total(row.get("total"))
    except ValidationError as e:
        raise field_error("total", e)

    names: list[str] = []
    try:
        for raw in _split_list(row.get("passengers") or ""):
            names.append(parse_name(raw, names))
        if not config.MIN_PASSENGERS <= len(names) <= config.MAX_PASSENGERS:
            raise ValidationError(
                f"need {config.MIN_PASSENGERS}-{config.MAX_PASSENGERS} passengers, got {len(names)}")
    except ValidationError as e:
        raise field_error("passengers", e)

    method_raw = clean_text(row.get("method")) or "equal"
    try:
        method = parse_choice(method_raw, config.METHODS, "Method")
    except ValidationError as e:
        raise field_error("method", e)

    values: list[Decimal] | None = None
    if method != "equal":
        try:
            parts = _split_list(row.get("shares") or "")
            if len(parts) != len(names):
                raise ValidationError(
                    f"{len(parts)} value(s) given for {len(names)} passengers")
            values = [parse_positive_decimal(p, "Share value") for p in parts]
        except ValidationError as e:
            raise field_error("shares", e)
    try:
        amounts = compute_shares(total, method, len(names), values)
    except ValidationError as e:
        raise field_error("shares", e)

    try:
        status = parse_choice(clean_text(row.get("status")) or "pending", config.STATUSES, "Status")
    except ValidationError as e:
        raise field_error("status", e)
    due_raw = clean_text(row.get("due_date"))
    try:
        due = parse_due_date(due_raw, date_) if due_raw else None
        note = parse_note(row.get("note"))
    except ValidationError as e:
        raise field_error("due_date/note", e)

    return Ride(
        id=ride_id, date=date_, origin=origin, destination=destination, category=category,
        total=total, method=method,
        passengers=[Passenger(n, a) for n, a in zip(names, amounts)],
        status=status, due_date=due, note=note,
    ).validate()


def _signature(r: Ride) -> tuple:
    return (r.date, r.origin.casefold(), r.destination.casefold(), r.total,
            tuple(sorted(n.casefold() for n in r.passenger_names)))


def import_csv(path: Path | str, store: RideStore, log_dir=config.REPORT_DIR) -> ImportResult:
    """Import a CSV into the store. Never raises for bad data - see the result."""
    result = ImportResult()
    path = Path(path).expanduser()
    log_lines: list[str] = []

    def finish() -> ImportResult:
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        try:
            Path(log_dir).mkdir(parents=True, exist_ok=True)
            log = Path(log_dir) / f"import_log_{stamp}.txt"
            header = [
                f"Import log - {datetime.now():%Y-%m-%d %H:%M:%S}",
                f"File: {path}",
                f"Rows read: {result.rows_read} | added: {result.added} | "
                f"duplicates skipped: {result.duplicates} | rejected: {result.rejected}",
                "-" * 60,
            ]
            if result.fatal:
                header.append(f"FATAL: {result.fatal}")
            log.write_text("\n".join(header + log_lines) + "\n", encoding="utf-8")
            result.log_path = log
        except OSError:
            result.log_path = None
        return result

    if not path.is_file():
        result.fatal = f"File not found: {path}"
        return finish()
    try:
        text = path.read_text(encoding="utf-8-sig")
    except (OSError, UnicodeDecodeError) as exc:
        result.fatal = f"Cannot read file as UTF-8 text: {exc}"
        return finish()
    if not text.strip():
        result.fatal = "File is empty."
        return finish()

    try:
        reader = csv.DictReader(io.StringIO(text, newline=""))
        headers = [clean_text(h).lower() for h in (reader.fieldnames or [])]
        reader.fieldnames = headers
        missing = [c for c in REQUIRED if c not in headers]
        if missing:
            result.fatal = f"Missing required column(s): {', '.join(missing)}"
            return finish()

        known = {_signature(r) for r in store.rides}
        new_rides: list[Ride] = []
        id_counter = int(store.next_id()[1:])
        for row in reader:
            line = reader.line_num
            if not any(clean_text(v) for v in row.values() if isinstance(v, str)):
                continue                              # blank line
            result.rows_read += 1
            if None in row:                           # more cells than headers
                msg = f"Line {line}: too many columns in row"
                result.errors.append(msg)
                log_lines.append(f"ERROR  {msg}")
                continue
            try:
                ride = _row_to_ride(row, f"R{id_counter:03d}")
            except ValidationError as exc:
                msg = f"Line {line}: {exc}"
                result.errors.append(msg)
                log_lines.append(f"ERROR  {msg}")
                continue
            sig = _signature(ride)
            if sig in known:
                result.duplicates += 1
                log_lines.append(f"SKIP   Line {line}: duplicate of an existing ride")
                continue
            known.add(sig)
            new_rides.append(ride)
            id_counter += 1
            log_lines.append(f"OK     Line {line}: {ride.id} {ride.route} {ride.total}")
    except csv.Error as exc:
        result.fatal = f"Malformed CSV: {exc}"
        return finish()

    for ride in new_rides:
        store.add(ride, save=False)
    if new_rides:
        store.save()
    result.added = len(new_rides)
    return finish()
