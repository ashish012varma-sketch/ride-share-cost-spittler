"""Multi-format report export: Markdown, plain-text audit log and CSV."""

from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path

from . import config
from .formatting import format_table, money
from .models import Ride
from .search import sort_newest_first
from .summary import Summary

SYM = config.FILE_CURRENCY


def _stamp() -> str:
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def _ensure(directory: Path | str) -> Path:
    path = Path(directory)
    path.mkdir(parents=True, exist_ok=True)
    return path


def _md_table(headers, rows) -> list[str]:
    out = ["| " + " | ".join(headers) + " |", "|" + "|".join("---" for _ in headers) + "|"]
    for row in rows:
        out.append("| " + " | ".join(str(c).replace("|", "\\|") for c in row) + " |")
    return out


def export_markdown(rides: list[Ride], summary: Summary, directory=config.REPORT_DIR) -> Path:
    path = _ensure(directory) / f"ride_report_{_stamp()}.md"
    m = lambda v: money(v, SYM)
    lines = [
        "# Ride Share Cost Splitter - Summary Report",
        "",
        f"_Generated {datetime.now():%Y-%m-%d %H:%M}_",
        "",
        "## Overview",
        "",
        *_md_table(["Metric", "Value"], [
            ("Rides recorded", summary.count),
            ("Total fares", m(summary.total)),
            ("Average fare", m(summary.average)),
            ("Median fare", m(summary.median)),
            ("Average share per passenger", m(summary.avg_share)),
            ("Average passengers per ride", summary.avg_passengers),
            ("Rides with unequal split", summary.unequal_count),
            ("Settled", f"{summary.settled_count} ({m(summary.settled_amount)})"),
            ("Pending", f"{summary.pending_count} ({m(summary.pending_amount)})"),
            ("Overdue", summary.overdue_count),
        ]),
        "",
        f"**Trend:** {summary.trend}",
        "",
        "## Spending by category",
        "",
        *_md_table(["Category", "Rides", "Total", "Share %"],
                   [(c, n, m(t), f"{p}%") for c, n, t, p in summary.by_category]),
        "",
        "## Monthly totals",
        "",
        *_md_table(["Month", "Rides", "Total"], [(mo, n, m(t)) for mo, n, t in summary.monthly]),
        "",
        "## Who owes what",
        "",
        *_md_table(["Passenger", "Rides", "Total share", "Still pending"],
                   [(n, c, m(t), m(p)) for n, c, t, p in summary.people]),
        "",
        "## Warnings",
        "",
    ]
    if summary.alerts:
        lines += [f"- **{a.level}** {a.ride_id}: {a.message}" for a in summary.alerts]
    else:
        lines.append("No warnings.")
    lines += ["", "## All rides", "",
              *_md_table(["ID", "Date", "Route", "Category", "Total", "Split", "Status", "Shares"],
                         [(r.id, r.date, r.route, r.category, m(r.total), r.method, r.status,
                           "; ".join(f"{p.name} {m(p.share)}" for p in r.passengers))
                          for r in sort_newest_first(rides)])]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def export_audit_log(rides: list[Ride], summary: Summary, directory=config.REPORT_DIR) -> Path:
    path = _ensure(directory) / f"ride_audit_{_stamp()}.txt"
    m = lambda v: money(v, SYM)
    out = [
        "RIDE SHARE COST SPLITTER - AUDIT LOG",
        f"Generated : {datetime.now():%Y-%m-%d %H:%M:%S}",
        f"Records   : {summary.count}    Total: {m(summary.total)}",
        "=" * 72,
        "",
    ]
    for r in sort_newest_first(rides):
        out.append(f"[{r.id}] {r.date}  {r.route}  ({r.category})")
        out.append(f"      Total {m(r.total)} | split: {config.METHOD_LABELS[r.method]} | "
                   f"status: {r.status}" + (f" | due {r.due_date}" if r.due_date else ""))
        for p in r.passengers:
            out.append(f"        - {p.name:<22}{m(p.share):>14}")
        check = sum(p.share for p in r.passengers)
        out.append(f"      Check: shares sum {m(check)} "
                   f"{'== total OK' if check == r.total else '!= total MISMATCH'}")
        if r.note:
            out.append(f"      Note: {r.note}")
        out.append("")
    out += ["=" * 72, "WARNINGS"]
    out += [f"  {a.level:<8} {a.ride_id}: {a.message}" for a in summary.alerts] or ["  none"]
    path.write_text("\n".join(out) + "\n", encoding="utf-8")
    return path


def export_csv(rides: list[Ride], directory=config.REPORT_DIR) -> Path:
    """One row per passenger share - easy to pivot in a spreadsheet."""
    path = _ensure(directory) / f"ride_report_{_stamp()}.csv"
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["ride_id", "date", "origin", "destination", "category", "total_fare",
                    "split_method", "status", "due_date", "passenger", "share", "note"])
        for r in sort_newest_first(rides):
            for p in r.passengers:
                w.writerow([r.id, r.date, r.origin, r.destination, r.category, f"{r.total:.2f}",
                            r.method, r.status, r.due_date or "", p.name, f"{p.share:.2f}", r.note])
    return path


def export_all(rides: list[Ride], summary: Summary, directory=config.REPORT_DIR) -> list[Path]:
    return [export_markdown(rides, summary, directory),
            export_audit_log(rides, summary, directory),
            export_csv(rides, directory)]
