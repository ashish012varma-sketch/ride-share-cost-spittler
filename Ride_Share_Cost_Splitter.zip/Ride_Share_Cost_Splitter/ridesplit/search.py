"""Keyword and category based record filtering."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Iterable

from .models import Ride


@dataclass
class Filters:
    keyword: str = ""
    category: str | None = None
    status: str | None = None
    passenger: str = ""
    date_from: str | None = None
    date_to: str | None = None
    min_total: Decimal | None = None
    max_total: Decimal | None = None

    def is_empty(self) -> bool:
        return not any([self.keyword, self.category, self.status, self.passenger,
                        self.date_from, self.date_to,
                        self.min_total is not None, self.max_total is not None])


def _haystack(ride: Ride) -> str:
    parts = [ride.id, ride.origin, ride.destination, ride.category, ride.note,
             ride.status, ride.method, ride.date, *ride.passenger_names]
    return " ".join(parts).casefold()


def filter_rides(rides: Iterable[Ride], f: Filters) -> list[Ride]:
    """Every keyword token must appear somewhere in the record (AND logic)."""
    tokens = [t for t in f.keyword.casefold().split() if t]
    who = f.passenger.casefold().strip()
    out: list[Ride] = []
    for r in rides:
        if f.category and r.category != f.category:
            continue
        if f.status and r.status != f.status:
            continue
        if f.date_from and r.date < f.date_from:
            continue
        if f.date_to and r.date > f.date_to:
            continue
        if f.min_total is not None and r.total < f.min_total:
            continue
        if f.max_total is not None and r.total > f.max_total:
            continue
        if who and not any(who in n.casefold() for n in r.passenger_names):
            continue
        if tokens:
            hay = _haystack(r)
            if not all(t in hay for t in tokens):
                continue
        out.append(r)
    return out


def sort_newest_first(rides: Iterable[Ride]) -> list[Ride]:
    return sorted(rides, key=lambda r: (r.date, r.id), reverse=True)
