"""Data structures for ride records, with schema validation on load."""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any

from . import config
from .validation import (
    ValidationError,
    parse_amount,
    parse_choice,
    parse_date,
    parse_due_date,
    parse_name,
    parse_note,
    parse_place,
    parse_ride_id,
)


@dataclass
class Passenger:
    name: str
    share: Decimal


@dataclass
class Ride:
    id: str
    date: str
    origin: str
    destination: str
    category: str
    total: Decimal
    method: str
    passengers: list[Passenger]
    status: str = "pending"
    due_date: str | None = None
    note: str = ""

    @property
    def route(self) -> str:
        return f"{self.origin} -> {self.destination}"

    @property
    def passenger_names(self) -> list[str]:
        return [p.name for p in self.passengers]

    def validate(self) -> "Ride":
        """Check every invariant; raises ValidationError. Returns self."""
        parse_ride_id(self.id)
        parse_date(self.date, allow_future=True)
        parse_place(self.origin, "Origin")
        parse_place(self.destination, "Destination")
        if self.category not in config.CATEGORIES:
            raise ValidationError(f"Unknown category '{self.category}'.")
        if self.method not in config.METHODS:
            raise ValidationError(f"Unknown split method '{self.method}'.")
        if self.status not in config.STATUSES:
            raise ValidationError(f"Unknown status '{self.status}'.")
        if not config.MIN_TOTAL <= self.total <= config.MAX_TOTAL:
            raise ValidationError("Total fare is outside the allowed range.")
        if not config.MIN_PASSENGERS <= len(self.passengers) <= config.MAX_PASSENGERS:
            raise ValidationError(
                f"A ride needs {config.MIN_PASSENGERS}-{config.MAX_PASSENGERS} passengers."
            )
        seen: list[str] = []
        for p in self.passengers:
            parse_name(p.name, seen)
            seen.append(p.name)
            if p.share <= 0:
                raise ValidationError(f"Share for {p.name} must be greater than zero.")
        if sum(p.share for p in self.passengers) != self.total:
            raise ValidationError("Passenger shares do not add up to the total fare.")
        if self.due_date:
            parse_due_date(self.due_date, self.date)
        return self

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "date": self.date,
            "origin": self.origin,
            "destination": self.destination,
            "category": self.category,
            "total": float(self.total),
            "method": self.method,
            "passengers": [{"name": p.name, "share": float(p.share)} for p in self.passengers],
            "status": self.status,
            "due_date": self.due_date,
            "note": self.note,
        }

    @classmethod
    def from_dict(cls, data: Any) -> "Ride":
        """Build and validate a Ride from a loosely-typed dict (JSON record)."""
        if not isinstance(data, dict):
            raise ValidationError("Record is not an object.")
        missing = [k for k in ("id", "date", "origin", "destination", "category",
                               "total", "passengers") if k not in data]
        if missing:
            raise ValidationError(f"Missing field(s): {', '.join(missing)}.")
        raw_passengers = data["passengers"]
        if not isinstance(raw_passengers, list):
            raise ValidationError("'passengers' must be a list.")
        passengers = []
        for item in raw_passengers:
            if not isinstance(item, dict) or "name" not in item or "share" not in item:
                raise ValidationError("Each passenger needs a name and a share.")
            passengers.append(
                Passenger(
                    name=parse_name(item["name"]),
                    share=parse_amount(item["share"], label="Share", minimum=Decimal("0.01")),
                )
            )
        ride = cls(
            id=parse_ride_id(data["id"]),
            date=parse_date(data["date"], allow_future=True),
            origin=parse_place(data["origin"], "Origin"),
            destination=parse_place(data["destination"], "Destination"),
            category=parse_choice(data["category"], config.CATEGORIES, "Category"),
            total=parse_amount(data["total"], label="Total fare"),
            method=parse_choice(data.get("method", "equal"), config.METHODS, "Method"),
            passengers=passengers,
            status=parse_choice(data.get("status", "pending"), config.STATUSES, "Status"),
            due_date=(parse_date(data["due_date"], allow_future=True)
                      if data.get("due_date") else None),
            note=parse_note(data.get("note", "")),
        )
        return ride.validate()
