"""Central configuration: paths, domain limits and warning thresholds."""

from decimal import Decimal
from pathlib import Path

APP_NAME = "RideSplit"
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
DATA_FILE = DATA_DIR / "rides.json"
REPORT_DIR = BASE_DIR / "reports"
SAMPLE_DIR = BASE_DIR / "sample_data"
SAMPLE_JSON = SAMPLE_DIR / "sample_rides.json"
LEGACY_CSV = SAMPLE_DIR / "legacy_import_sample.csv"

SCHEMA_VERSION = 1

# Console currency symbol (ui.setup_console falls back to "Rs." if the
# terminal cannot print the rupee sign). Files are always UTF-8.
CURRENCY = "₹"
FILE_CURRENCY = "₹"

# Domain limits (validation)
MIN_TOTAL = Decimal("1.00")
MAX_TOTAL = Decimal("100000.00")
MIN_PASSENGERS = 2
MAX_PASSENGERS = 12
MIN_DATE_YEAR = 2000
MAX_NAME_LEN = 30
MAX_PLACE_LEN = 60
MAX_NOTE_LEN = 120

CATEGORIES = ("Cab", "Auto", "Carpool", "Airport", "Intercity", "Bike", "Other")
METHODS = ("equal", "percent", "exact", "weights")
METHOD_LABELS = {
    "equal": "Equal split",
    "percent": "By percentage",
    "exact": "Exact amounts",
    "weights": "By ratio / weights",
}
STATUSES = ("pending", "settled")

# Threshold warnings
HIGH_FARE_THRESHOLD = Decimal("5000.00")   # single-ride fare considered unusual
DOMINANT_SHARE_PCT = Decimal("75")         # one person paying >= this % (3+ riders)
DUE_SOON_DAYS = 2
OUTLIER_STDEVS = 2                         # fare > mean + N*stdev (needs 6+ rides)
OUTLIER_MIN_RIDES = 6

PAGE_SIZE = 10
