"""Executive summary: totals, averages, status indicators and key trends."""

from __future__ import annotations

import statistics
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal

from . import config
from .alerts import Alert, compute_alerts
from .models import Ride
from .validation import month_key

ZERO = Decimal("0.00")
CENT = Decimal("0.01")


def _q(value: Decimal | float) -> Decimal:
    return Decimal(str(value)).quantize(CENT)


@dataclass
class Summary:
    count: int = 0
    total: Decimal = ZERO
    average: Decimal = ZERO
    median: Decimal = ZERO
    highest: Ride | None = None
    lowest: Ride | None = None
    avg_passengers: Decimal = ZERO
    avg_share: Decimal = ZERO
    unequal_count: int = 0
    settled_count: int = 0
    pending_count: int = 0
    overdue_count: int = 0
    settled_amount: Decimal = ZERO
    pending_amount: Decimal = ZERO
    by_category: list[tuple[str, int, Decimal, Decimal]] = field(default_factory=list)
    monthly: list[tuple[str, int, Decimal]] = field(default_factory=list)
    people: list[tuple[str, int, Decimal, Decimal]] = field(default_factory=list)
    top_route: tuple[str, int] | None = None
    busiest_weekday: tuple[str, int] | None = None
    trend: str = "Not enough data for a trend yet."
    alerts: list[Alert] = field(default_factory=list)


def compute_summary(rides: list[Ride], today: date | None = None) -> Summary:
    today = today or date.today()
    s = Summary()
    s.count = len(rides)
    if not rides:
        return s

    totals = [r.total for r in rides]
    s.total = sum(totals, ZERO)
    s.average = _q(s.total / s.count)
    s.median = _q(statistics.median(float(t) for t in totals))
    s.highest = max(rides, key=lambda r: r.total)
    s.lowest = min(rides, key=lambda r: r.total)
    passenger_total = sum(len(r.passengers) for r in rides)
    s.avg_passengers = _q(Decimal(passenger_total) / s.count)
    s.avg_share = _q(s.total / passenger_total)
    s.unequal_count = sum(1 for r in rides if r.method != "equal")

    for r in rides:
        if r.status == "settled":
            s.settled_count += 1
            s.settled_amount += r.total
        else:
            s.pending_count += 1
            s.pending_amount += r.total
            if r.due_date and r.due_date < today.isoformat():
                s.overdue_count += 1

    cat_count: Counter[str] = Counter()
    cat_total: dict[str, Decimal] = defaultdict(lambda: ZERO)
    month_count: Counter[str] = Counter()
    month_total: dict[str, Decimal] = defaultdict(lambda: ZERO)
    routes: Counter[str] = Counter()
    weekdays: Counter[str] = Counter()
    person: dict[str, list] = {}   # key -> [display, rides, total, pending]
    for r in rides:
        cat_count[r.category] += 1
        cat_total[r.category] += r.total
        m = month_key(r.date)
        month_count[m] += 1
        month_total[m] += r.total
        routes[f"{r.origin} -> {r.destination}"] += 1
        weekdays[date.fromisoformat(r.date).strftime("%A")] += 1
        for p in r.passengers:
            rec = person.setdefault(p.name.casefold(), [p.name, 0, ZERO, ZERO])
            rec[1] += 1
            rec[2] += p.share
            if r.status == "pending":
                rec[3] += p.share

    s.by_category = sorted(
        ((c, cat_count[c], cat_total[c], _q(cat_total[c] / s.total * 100)) for c in cat_count),
        key=lambda x: x[2], reverse=True)
    s.monthly = [(m, month_count[m], month_total[m]) for m in sorted(month_count)]
    s.people = sorted(((v[0], v[1], v[2], v[3]) for v in person.values()),
                      key=lambda x: (-x[2], x[0].casefold()))
    s.top_route = routes.most_common(1)[0]
    s.busiest_weekday = weekdays.most_common(1)[0]

    # Trend: compare the last two COMPLETE months (the current month is still filling up).
    this_month = today.strftime("%Y-%m")
    complete = [m for m in s.monthly if m[0] != this_month]
    basis = complete if len(complete) >= 2 else s.monthly
    if len(basis) >= 2:
        (prev_m, _, prev_t), (last_m, _, last_t) = basis[-2], basis[-1]
        change = (last_t - prev_t) / prev_t * 100 if prev_t else Decimal(0)
        word = "FLAT" if abs(change) < 5 else ("UP" if change > 0 else "DOWN")
        s.trend = f"Spending {word} {abs(change):.1f}% ({prev_m} -> {last_m})"
        if basis is complete and this_month in {m[0] for m in s.monthly}:
            s.trend += "; current month excluded (still in progress)"

    s.alerts = compute_alerts(rides, today)
    return s
