"""Threshold warning indicators: overdue dues, anomalies and limit breaches."""

from __future__ import annotations

import statistics
from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal
from typing import Iterable

from . import config
from .formatting import money
from .models import Ride

CRITICAL, WARNING, INFO = "CRITICAL", "WARNING", "INFO"
_ORDER = {CRITICAL: 0, WARNING: 1, INFO: 2}


@dataclass(frozen=True)
class Alert:
    level: str
    ride_id: str
    message: str


def compute_alerts(rides: Iterable[Ride], today: date | None = None) -> list[Alert]:
    today = today or date.today()
    rides = list(rides)
    alerts: list[Alert] = []

    totals = [float(r.total) for r in rides]
    mean = stdev = None
    if len(totals) >= config.OUTLIER_MIN_RIDES:
        mean = statistics.mean(totals)
        stdev = statistics.pstdev(totals)

    seen: dict[tuple, str] = {}
    for r in rides:
        # --- payment deadlines
        if r.status == "pending" and r.due_date:
            due = date.fromisoformat(r.due_date)
            if due < today:
                days = (today - due).days
                alerts.append(Alert(CRITICAL, r.id,
                    f"OVERDUE by {days} day{'s' if days != 1 else ''} "
                    f"({money(r.total)}, {r.route}, due {r.due_date})"))
            elif due <= today + timedelta(days=config.DUE_SOON_DAYS):
                alerts.append(Alert(WARNING, r.id,
                    f"Payment due {r.due_date} ({money(r.total)}, {r.route})"))

        # --- limit breaches / anomalies
        if r.total >= config.HIGH_FARE_THRESHOLD:
            alerts.append(Alert(WARNING, r.id,
                f"High fare {money(r.total)} (threshold {money(config.HIGH_FARE_THRESHOLD)})"))
        elif mean is not None and stdev and float(r.total) > mean + config.OUTLIER_STDEVS * stdev:
            alerts.append(Alert(INFO, r.id,
                f"Fare {money(r.total)} is unusually high versus your average {money(Decimal(str(round(mean, 2))))}"))

        if len(r.passengers) >= 3:
            top = max(r.passengers, key=lambda p: p.share)
            pct = top.share / r.total * 100
            if pct >= config.DOMINANT_SHARE_PCT:
                alerts.append(Alert(INFO, r.id,
                    f"{top.name} carries {pct:.0f}% of a {len(r.passengers)}-person ride"))

        if r.date > today.isoformat():
            alerts.append(Alert(WARNING, r.id, f"Ride is dated in the future ({r.date})"))

        # --- duplicates
        key = (r.date, r.origin.casefold(), r.destination.casefold(), r.total,
               tuple(sorted(n.casefold() for n in r.passenger_names)))
        if key in seen:
            alerts.append(Alert(WARNING, r.id, f"Possible duplicate of {seen[key]}"))
        else:
            seen[key] = r.id

    alerts.sort(key=lambda a: (_ORDER[a.level], a.ride_id))
    return alerts
