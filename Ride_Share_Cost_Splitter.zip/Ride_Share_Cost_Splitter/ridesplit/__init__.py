"""RideSplit - Ride Share Cost Splitter (zero-dependency, Python 3.10+)."""

__version__ = "1.0.0"
