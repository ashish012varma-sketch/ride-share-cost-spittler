"""Plain-text formatting helpers (no ANSI here, so they are safe for files)."""

from __future__ import annotations

from decimal import Decimal
from typing import Callable, Sequence

from . import config


def money(value: Decimal | float | int, symbol: str | None = None) -> str:
    sym = config.CURRENCY if symbol is None else symbol
    return f"{sym}{Decimal(str(value)):,.2f}"


def fit(text: object, width: int) -> str:
    s = str(text)
    if len(s) <= width:
        return s
    return s[: max(width - 3, 1)] + "..." if width > 3 else s[:width]


def format_table(
    headers: Sequence[str],
    rows: Sequence[Sequence[object]],
    aligns: str | None = None,
    max_width: int = 26,
    style: Callable[[int, int, str], str] | None = None,
) -> list[str]:
    """Fixed-width ASCII table.

    aligns: one char per column, 'l' or 'r' (default left).
    style:  optional callback (row_index, col_index, padded_text) -> text,
            used by the UI to colour cells after padding (so widths stay right).
    """
    n = len(headers)
    aligns = (aligns or "l" * n).ljust(n, "l")
    cells = [[fit(c, max_width) for c in row] for row in rows]
    widths = [
        max([len(headers[i])] + [len(row[i]) for row in cells]) for i in range(n)
    ]

    def pad(text: str, i: int) -> str:
        return text.rjust(widths[i]) if aligns[i] == "r" else text.ljust(widths[i])

    sep = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    lines = [sep, "| " + " | ".join(pad(headers[i], i) for i in range(n)) + " |", sep]
    for r, row in enumerate(cells):
        out = []
        for i in range(n):
            padded = pad(row[i], i)
            out.append(style(r, i, padded) if style else padded)
        lines.append("| " + " | ".join(out) + " |")
    lines.append(sep)
    return lines


def bar_chart(items: Sequence[tuple[str, Decimal]], width: int = 32) -> list[str]:
    """Horizontal ASCII bar chart; works in any terminal."""
    if not items:
        return []
    peak = max((v for _, v in items), default=Decimal(0)) or Decimal(1)
    label_w = max(len(str(label)) for label, _ in items)
    lines = []
    for label, value in items:
        filled = int((value / peak * width).to_integral_value())
        filled = max(filled, 1) if value > 0 else 0
        lines.append(f"{str(label).ljust(label_w)} | {'#' * filled:<{width}} {money(value)}")
    return lines
