"""Optional Matplotlib chart export. The app works without Matplotlib installed."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from . import config
from .summary import Summary


def matplotlib_available() -> bool:
    try:
        import matplotlib  # noqa: F401
        return True
    except ImportError:
        return False


def export_chart(summary: Summary, directory=config.REPORT_DIR) -> Path | None:
    """Save a 2-panel PNG (category spend + monthly trend). None if unavailable."""
    if not summary.count:
        return None
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return None

    out_dir = Path(directory)
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"ride_chart_{datetime.now():%Y%m%d-%H%M%S}.png"

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.2))
    cats = [c for c, *_ in summary.by_category]
    ax1.bar(cats, [float(t) for _, _, t, _ in summary.by_category], color="#2f6fed")
    ax1.set_title("Spend by category")
    ax1.set_ylabel("Rupees")
    ax1.tick_params(axis="x", rotation=30)
    months = [m for m, _, _ in summary.monthly]
    ax2.plot(months, [float(t) for _, _, t in summary.monthly], marker="o", color="#e8590c")
    ax2.set_title("Monthly total")
    ax2.tick_params(axis="x", rotation=30)
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)
    return path
