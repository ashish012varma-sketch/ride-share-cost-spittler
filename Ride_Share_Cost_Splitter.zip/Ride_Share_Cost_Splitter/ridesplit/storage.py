"""Local JSON persistence with schema checks and self-healing on corruption."""

from __future__ import annotations

import json
import os
import re
import shutil
from datetime import datetime
from pathlib import Path

from . import config
from .models import Ride
from .validation import ValidationError


class StorageError(Exception):
    """Raised when data cannot be written to disk."""


class RideStore:
    def __init__(self, path: Path | str = config.DATA_FILE):
        self.path = Path(path)
        self.rides: list[Ride] = []
        self.notes: list[str] = []   # human-readable messages from load()

    # ---------------------------------------------------------------- loading
    def load(self) -> list[str]:
        """Read the data file. Never raises for bad/missing data; returns notes."""
        self.notes = []
        self.rides = []
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise StorageError(f"Cannot create data folder {self.path.parent}: {exc}")

        if not self.path.exists():
            self.notes.append(f"No data file found - created a fresh one at {self.path.name}.")
            self.save()
            return self.notes

        try:
            text = self.path.read_text(encoding="utf-8-sig")
            if not text.strip():
                raise ValueError("file is empty")
            payload = json.loads(text)
            if isinstance(payload, dict):
                records = payload.get("rides")
            else:
                records = payload          # tolerate a bare list
            if not isinstance(records, list):
                raise ValueError("no 'rides' list found")
        except (OSError, UnicodeDecodeError, ValueError) as exc:   # JSONDecodeError is a ValueError
            backup = self._quarantine()
            self.notes.append(
                f"Data file was unreadable ({exc}). "
                + (f"Saved a copy as {backup.name} and " if backup else "")
                + "started with a clean file."
            )
            self.save()
            return self.notes

        seen: set[str] = set()
        skipped = 0
        for index, record in enumerate(records, start=1):
            try:
                ride = Ride.from_dict(record)
                if ride.id in seen:
                    raise ValidationError(f"duplicate id {ride.id}")
                seen.add(ride.id)
                self.rides.append(ride)
            except ValidationError as exc:
                skipped += 1
                self.notes.append(f"Skipped record #{index}: {exc}")
        if skipped:
            self.notes.append(f"{skipped} invalid record(s) skipped; {len(self.rides)} loaded.")
        return self.notes

    def _quarantine(self) -> Path | None:
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        target = self.path.with_name(f"{self.path.stem}.corrupt-{stamp}{self.path.suffix}")
        try:
            shutil.copy2(self.path, target)
            return target
        except OSError:
            return None

    # ----------------------------------------------------------------- saving
    def save(self) -> None:
        """Atomic write: temp file + rename, so a crash can't leave a half file."""
        payload = {
            "schema_version": config.SCHEMA_VERSION,
            "saved_at": datetime.now().isoformat(timespec="seconds"),
            "rides": [r.to_dict() for r in self.rides],
        }
        tmp = self.path.with_name(self.path.name + ".tmp")
        try:
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, indent=2, ensure_ascii=False)
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(tmp, self.path)
        except OSError as exc:
            raise StorageError(f"Could not save data to {self.path}: {exc}")

    def backup(self) -> Path | None:
        if not self.path.exists():
            return None
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        target = self.path.with_name(f"{self.path.stem}.backup-{stamp}{self.path.suffix}")
        try:
            shutil.copy2(self.path, target)
            return target
        except OSError:
            return None

    # ------------------------------------------------------------- operations
    def next_id(self) -> str:
        numbers = [int(m.group(1)) for r in self.rides if (m := re.fullmatch(r"R(\d+)", r.id))]
        return f"R{(max(numbers) + 1) if numbers else 1:03d}"

    def get(self, ride_id: str) -> Ride | None:
        return next((r for r in self.rides if r.id == ride_id), None)

    def add(self, ride: Ride, *, save: bool = True) -> Ride:
        ride.validate()
        self.rides.append(ride)
        if save:
            self.save()
        return ride

    def delete(self, ride_id: str) -> bool:
        ride = self.get(ride_id)
        if not ride:
            return False
        self.rides.remove(ride)
        self.save()
        return True

    def set_status(self, ride_id: str, status: str) -> bool:
        ride = self.get(ride_id)
        if not ride:
            return False
        ride.status = status
        self.save()
        return True

    def replace_all(self, rides: list[Ride]) -> None:
        self.rides = list(rides)
        self.save()
