"""Menu-driven application: wires user actions to the backend modules."""

from __future__ import annotations

import json
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path
from typing import Callable

from . import calculator, charts, config, exporter, importer, ui
from .alerts import CRITICAL, INFO, WARNING, compute_alerts
from .formatting import bar_chart, money
from .models import Passenger, Ride
from .search import Filters, filter_rides, sort_newest_first
from .storage import RideStore, StorageError
from .summary import compute_summary
from .ui import Cancelled, c
from .validation import (
    ValidationError,
    parse_choice,
    parse_date,
    parse_due_date,
    parse_int,
    parse_name,
    parse_note,
    parse_place,
    parse_positive_decimal,
    parse_ride_id,
    parse_total,
    parse_amount,
)

LEVEL_STYLE = {CRITICAL: ("red", "bold"), WARNING: ("yellow", "bold"), INFO: ("cyan",)}


class App:
    def __init__(self, store: RideStore, today: Callable[[], date] = date.today):
        self.store = store
        self.today = today

    # ============================================================== startup
    def start(self) -> None:
        ui.banner()
        try:
            notes = self.store.load()
        except StorageError as exc:
            ui.err(str(exc))
            return
        for note in notes:
            ui.warn(note)
        ui.info(f"{len(self.store.rides)} ride(s) loaded from {self.store.path.name}")
        self._show_alert_badge()
        self.menu_loop()

    def _show_alert_badge(self) -> None:
        alerts = compute_alerts(self.store.rides, self.today())
        crit = sum(1 for a in alerts if a.level == CRITICAL)
        if alerts:
            ui.warn(f"{len(alerts)} warning(s) found ({crit} critical) - choose option 7 to review.")

    # ================================================================ menu
    def menu_loop(self) -> None:
        actions: dict[str, tuple[str, Callable[[], None]]] = {
            "1": ("Add a ride & split the cost", self.add_ride),
            "2": ("View all rides", self.view_rides),
            "3": ("Search & filter rides", self.search_rides),
            "4": ("Update payment status", self.update_status),
            "5": ("Delete a ride", self.delete_ride),
            "6": ("Executive summary", self.show_summary),
            "7": ("Warnings & alerts", self.show_alerts),
            "8": ("Export reports (MD / TXT / CSV / chart)", self.export_reports),
            "9": ("Import legacy CSV", self.import_legacy),
            "10": ("Load sample dataset", self.load_sample),
        }
        while True:
            ui.heading("MAIN MENU")
            for key, (label, _) in actions.items():
                print(f"  {c(key.rjust(2), 'bold', 'cyan')}  {label}")
            print(f"  {c(' 0', 'bold', 'cyan')}  Exit")
            try:
                choice = input("\nSelect an option: ").strip().lower()
            except EOFError:
                print()
                return self._goodbye()
            except KeyboardInterrupt:
                print()
                return self._goodbye()
            if choice in ("0", "q", "quit", "exit"):
                return self._goodbye()
            if choice not in actions:
                ui.err("Please enter a number from the menu (0-10).")
                continue
            try:
                actions[choice][1]()
            except Cancelled:
                ui.info("Cancelled - nothing was changed.")
            except KeyboardInterrupt:
                print()
                ui.info("Interrupted - back to the menu.")
            except EOFError:
                print()
                return self._goodbye()
            except StorageError as exc:
                ui.err(str(exc))
            except Exception as exc:      # last-resort guard: never crash the demo
                ui.err(f"Unexpected problem ({type(exc).__name__}: {exc}). Your saved data is safe.")

    def _goodbye(self) -> None:
        ui.ok("Data is saved. Goodbye!")

    # =============================================================== 1. add
    def add_ride(self) -> None:
        ui.heading("ADD A RIDE")
        ui.info("Type ! at any prompt to cancel.")
        today = self.today()
        ride_date = ui.ask("Ride date", lambda t: parse_date(t, today=today),
                           default=today.isoformat(), hint="YYYY-MM-DD")
        origin = ui.ask("Pickup location", lambda t: parse_place(t, "Pickup"))
        destination = ui.ask("Drop location", lambda t: parse_place(t, "Drop"))
        print("Category:")
        category = ui.choose("Category", config.CATEGORIES)
        total = ui.ask("Total fare", parse_total,
                       hint=f"{config.CURRENCY}{config.MIN_TOTAL} - {config.CURRENCY}{config.MAX_TOTAL:,}")
        count = ui.ask("Number of passengers",
                       lambda t: parse_int(t, "Passengers", config.MIN_PASSENGERS, config.MAX_PASSENGERS),
                       hint=f"{config.MIN_PASSENGERS}-{config.MAX_PASSENGERS}")
        names: list[str] = []
        for i in range(count):
            names.append(ui.ask(f"  Passenger {i + 1} name",
                                lambda t, taken=tuple(names): parse_name(t, taken)))

        print("Split method:")
        labels = [config.METHOD_LABELS[m] for m in config.METHODS]
        picked = ui.choose("Split method", labels)
        method = config.METHODS[labels.index(picked)]
        shares = self._collect_shares(total, method, names)

        status = ui.ask("Payment status", lambda t: parse_choice(t, config.STATUSES, "Status"),
                        default="pending", hint="pending / settled")
        due = None
        if status == "pending":
            suggested = (date.fromisoformat(ride_date) + timedelta(days=7)).isoformat()
            due = ui.ask("Due date", lambda t: parse_due_date(t, ride_date),
                         default=suggested, hint="YYYY-MM-DD")
        note = ui.ask("Note", parse_note, allow_blank=True) or ""

        ride = Ride(
            id=self.store.next_id(), date=ride_date, origin=origin, destination=destination,
            category=category, total=total, method=method,
            passengers=[Passenger(n, s) for n, s in zip(names, shares)],
            status=status, due_date=due, note=note,
        ).validate()
        ui.heading("REVIEW")
        self._print_ride_detail(ride)
        if ui.confirm("Save this ride?", default=True):
            self.store.add(ride)
            ui.ok(f"Saved {ride.id}. Data written to {self.store.path.name}.")
        else:
            ui.info("Not saved.")

    def _collect_shares(self, total: Decimal, method: str, names: list[str]) -> list[Decimal]:
        if method == "equal":
            return calculator.compute_shares(total, "equal", len(names))
        label = {"percent": "Percent of fare", "exact": "Amount",
                 "weights": "Weight (e.g. 1, 1.5, 2)"}[method]
        while True:
            values: list[Decimal] = []
            for i, name in enumerate(names):
                last = i == len(names) - 1 and method in ("percent", "exact")
                if method == "percent":
                    left = Decimal(100) - sum(values, Decimal(0))
                    parser = lambda t: parse_positive_decimal(t, "Percentage", Decimal(100))
                    hint = f"{left}% left"
                elif method == "exact":
                    left = calculator.remaining(total, values)
                    parser = lambda t: parse_positive_decimal(t, "Amount", total)
                    hint = f"{money(left)} left"
                else:
                    parser = lambda t: parse_positive_decimal(t, "Weight", Decimal(1000))
                    hint = "relative weight"
                if last and left > 0:
                    raw = ui.ask(f"  {label} for {name}", parser, allow_blank=True,
                                 hint=f"{hint} - blank takes the rest")
                    values.append(left if raw is None else raw)
                else:
                    values.append(ui.ask(f"  {label} for {name}", parser, hint=hint))
            try:
                return calculator.compute_shares(total, method, len(names), values)
            except ValidationError as exc:
                ui.err(f"{exc} Let's re-enter the values.")

    # ============================================================== 2. view
    def _ride_rows(self, rides: list[Ride]):
        today = self.today().isoformat()
        rows = []
        for r in rides:
            overdue = r.status == "pending" and r.due_date and r.due_date < today
            rows.append([r.id, r.date, r.route, r.category, money(r.total), len(r.passengers),
                         "OVERDUE" if overdue else r.status])
        return rows

    @staticmethod
    def _status_style(_row, col, text):
        if col != 6:
            return text
        stripped = text.strip()
        if stripped == "OVERDUE":
            return c(text, "red", "bold")
        if stripped == "settled":
            return c(text, "green")
        return c(text, "yellow")

    _HEADERS = ["ID", "Date", "Route", "Category", "Total", "Pax", "Status"]
    _ALIGNS = "llllrrl"

    def _show_ride_list(self, rides: list[Ride]) -> None:
        paged_rows = self._ride_rows(sort_newest_first(rides))
        ui.paged_table(self._HEADERS, paged_rows, self._ALIGNS, max_width=34, style=self._status_style)

    def view_rides(self) -> None:
        ui.heading("ALL RIDES")
        if not self.store.rides:
            ui.info("No rides yet. Add one with option 1 or load sample data with option 10.")
            return
        rides = sort_newest_first(self.store.rides)
        self._show_ride_list(rides)
        self._detail_prompt(rides)

    def _detail_prompt(self, rides: list[Ride]) -> None:
        while True:
            raw = input("\nEnter a ride ID for the full split (blank to go back): ").strip()
            if raw == "" or raw == ui.CANCEL_TOKEN:
                return
            try:
                ride = self.store.get(parse_ride_id(raw))
            except ValidationError as exc:
                ui.err(str(exc))
                continue
            if ride is None:
                ui.err("No ride with that ID.")
                continue
            self._print_ride_detail(ride)

    def _print_ride_detail(self, ride: Ride) -> None:
        print(f"  {c(ride.id, 'bold')}  {ride.date}  {ride.route}  [{ride.category}]")
        print(f"  Total fare : {c(money(ride.total), 'bold')}   Split: {config.METHOD_LABELS[ride.method]}")
        status = ride.status
        if status == "pending" and ride.due_date:
            status += f" (due {ride.due_date})"
        print(f"  Status     : {status}")
        if ride.note:
            print(f"  Note       : {ride.note}")
        rows = [[p.name, money(p.share), f"{p.share / ride.total * 100:.2f}%"] for p in ride.passengers]
        rows.append(["TOTAL", money(sum(p.share for p in ride.passengers)), "100.00%"])
        ui.print_table(["Passenger", "Share", "% of fare"], rows, "lrr")

    # ============================================================ 3. search
    def search_rides(self) -> None:
        ui.heading("SEARCH & FILTER")
        ui.info("Leave a field blank to skip it. Filters combine (AND).")
        f = Filters()
        f.keyword = ui.ask("Keyword (place, name, note, id...)", lambda t: t, allow_blank=True) or ""
        cat = ui.ask("Category", lambda t: parse_choice(t, config.CATEGORIES, "Category"),
                     allow_blank=True, hint=", ".join(config.CATEGORIES))
        f.category = cat
        f.status = ui.ask("Status", lambda t: parse_choice(t, config.STATUSES, "Status"),
                          allow_blank=True, hint="pending / settled")
        f.passenger = ui.ask("Passenger name contains", lambda t: t, allow_blank=True) or ""
        f.date_from = ui.ask("From date", lambda t: parse_date(t, allow_future=True),
                             allow_blank=True, hint="YYYY-MM-DD")
        f.date_to = ui.ask("To date", lambda t: parse_date(t, allow_future=True),
                           allow_blank=True, hint="YYYY-MM-DD")
        if f.date_from and f.date_to and f.date_from > f.date_to:
            ui.warn("From date is after To date - swapping them.")
            f.date_from, f.date_to = f.date_to, f.date_from
        f.min_total = ui.ask("Minimum fare", lambda t: parse_amount(t, label="Minimum fare"),
                             allow_blank=True)
        f.max_total = ui.ask("Maximum fare", lambda t: parse_amount(t, label="Maximum fare"),
                             allow_blank=True)
        if f.min_total is not None and f.max_total is not None and f.min_total > f.max_total:
            ui.warn("Minimum is above maximum - swapping them.")
            f.min_total, f.max_total = f.max_total, f.min_total

        results = sort_newest_first(filter_rides(self.store.rides, f))
        ui.heading(f"{len(results)} MATCH(ES)")
        if not results:
            ui.info("No rides matched. Try fewer filters or a shorter keyword.")
            return
        print(f"  Matching total: {c(money(sum(r.total for r in results)), 'bold')}")
        self._show_ride_list(results)
        self._detail_prompt(results)

    # ============================================================ 4. status
    def update_status(self) -> None:
        ui.heading("UPDATE PAYMENT STATUS")
        if not self.store.rides:
            ui.info("No rides to update.")
            return
        ride = self._ask_existing_ride()
        self._print_ride_detail(ride)
        new = "settled" if ride.status == "pending" else "pending"
        if ui.confirm(f"Mark {ride.id} as {new.upper()}?", default=True):
            self.store.set_status(ride.id, new)
            ui.ok(f"{ride.id} is now {new}.")

    def _ask_existing_ride(self) -> Ride:
        def parser(text: str) -> Ride:
            ride = self.store.get(parse_ride_id(text))
            if ride is None:
                raise ValidationError("No ride with that ID. Use option 2 to list IDs.")
            return ride
        return ui.ask("Ride ID", parser, hint="e.g. R012 or 12")  # type: ignore[return-value]

    # ============================================================ 5. delete
    def delete_ride(self) -> None:
        ui.heading("DELETE A RIDE")
        if not self.store.rides:
            ui.info("No rides to delete.")
            return
        ride = self._ask_existing_ride()
        self._print_ride_detail(ride)
        if ui.confirm(f"Permanently delete {ride.id}?", default=False):
            self.store.delete(ride.id)
            ui.ok(f"{ride.id} deleted.")
        else:
            ui.info("Kept.")

    # =========================================================== 6. summary
    def show_summary(self) -> None:
        ui.heading("EXECUTIVE SUMMARY")
        s = compute_summary(self.store.rides, self.today())
        if not s.count:
            ui.info("No data yet - add rides or load the sample dataset first.")
            return
        ui.print_table(["Metric", "Value"], [
            ["Rides recorded", s.count],
            ["Total fares", money(s.total)],
            ["Average fare", money(s.average)],
            ["Median fare", money(s.median)],
            ["Highest fare", f"{money(s.highest.total)} ({s.highest.id})"],
            ["Lowest fare", f"{money(s.lowest.total)} ({s.lowest.id})"],
            ["Avg passengers / ride", s.avg_passengers],
            ["Avg share / passenger", money(s.avg_share)],
            ["Unequal splits", f"{s.unequal_count} of {s.count}"],
        ], "lr", max_width=40)

        print()
        print(c("  Payment status", "bold"))
        ui.print_table(["Status", "Rides", "Amount"], [
            ["Settled", s.settled_count, money(s.settled_amount)],
            ["Pending", s.pending_count, money(s.pending_amount)],
            ["  of which overdue", s.overdue_count, ""],
        ], "lrr")
        if s.overdue_count:
            ui.warn(f"{s.overdue_count} pending ride(s) are past their due date.")

        print()
        print(c("  Spending by category", "bold"))
        ui.print_table(["Category", "Rides", "Total", "Share"],
                       [[cat, n, money(t), f"{p}%"] for cat, n, t, p in s.by_category], "lrrr")
        for line in bar_chart([(cat, t) for cat, _, t, _ in s.by_category]):
            print("   " + line)

        print()
        print(c("  Monthly totals", "bold"))
        for line in bar_chart([(m, t) for m, _, t in s.monthly]):
            print("   " + line)
        print()
        print("  Trend: " + c(s.trend, "bold"))
        if s.top_route:
            print(f"  Most frequent route: {s.top_route[0]} ({s.top_route[1]} rides)")
        if s.busiest_weekday:
            print(f"  Busiest weekday    : {s.busiest_weekday[0]} ({s.busiest_weekday[1]} rides)")

        print()
        print(c("  Who owes what (top 10)", "bold"))
        ui.print_table(["Passenger", "Rides", "Total share", "Pending"],
                       [[n, k, money(t), money(p)] for n, k, t, p in s.people[:10]], "lrrr")
        if s.alerts:
            print()
            ui.warn(f"{len(s.alerts)} warning(s) - see option 7.")

    # ============================================================ 7. alerts
    def show_alerts(self) -> None:
        ui.heading("WARNINGS & ALERTS")
        alerts = compute_alerts(self.store.rides, self.today())
        if not alerts:
            ui.ok("All clear - no overdue payments or unusual entries.")
            return
        for a in alerts:
            tag = c(f"{a.level:<8}", *LEVEL_STYLE[a.level])
            print(f"  {tag} {a.ride_id}  {a.message}")
        print(f"\n  {len(alerts)} alert(s) in total.")

    # ============================================================ 8. export
    def export_reports(self) -> None:
        ui.heading("EXPORT REPORTS")
        if not self.store.rides:
            ui.info("Nothing to export yet.")
            return
        options = ["Markdown report (.md)", "Plain-text audit log (.txt)",
                   "CSV report (.csv)", "All three", "Chart image (.png)"]
        choice = ui.choose("Format", options)
        summary = compute_summary(self.store.rides, self.today())
        rides = self.store.rides
        paths: list[Path | None]
        if choice == options[0]:
            paths = [exporter.export_markdown(rides, summary)]
        elif choice == options[1]:
            paths = [exporter.export_audit_log(rides, summary)]
        elif choice == options[2]:
            paths = [exporter.export_csv(rides)]
        elif choice == options[3]:
            paths = list(exporter.export_all(rides, summary))
        else:
            chart = charts.export_chart(summary)
            if chart is None:
                ui.warn("Matplotlib is not installed, so no PNG was made "
                        "(optional: pip install matplotlib). The ASCII charts in the summary still work.")
                return
            paths = [chart]
        for p in paths:
            if p:
                ui.ok(f"Created {p}")

    # ============================================================ 9. import
    def import_legacy(self) -> None:
        ui.heading("IMPORT LEGACY CSV")
        ui.info("Columns: date, origin, destination, category, total, passengers "
                "(+ optional method, shares, status, due_date, note)")
        default = str(config.LEGACY_CSV) if config.LEGACY_CSV.exists() else None
        path = ui.ask("Path to CSV file", lambda t: t.strip().strip('"').strip("'"),
                      default=default) if default else \
            ui.ask("Path to CSV file", lambda t: t.strip().strip('"').strip("'"))
        result = importer.import_csv(path, self.store)
        if result.fatal:
            ui.err(result.fatal)
        else:
            ui.ok(f"Rows read: {result.rows_read} | added: {result.added} | "
                  f"duplicates skipped: {result.duplicates} | rejected: {result.rejected}")
            for line in result.errors[:15]:
                ui.err(line)
            if result.rejected > 15:
                ui.info(f"...and {result.rejected - 15} more - see the log file.")
        if result.log_path:
            ui.info(f"Row-by-row log: {result.log_path}")

    # ========================================================= 10. samples
    def load_sample(self) -> None:
        ui.heading("LOAD SAMPLE DATASET")
        if not config.SAMPLE_JSON.exists():
            ui.err(f"Sample file not found: {config.SAMPLE_JSON}")
            return
        try:
            payload = json.loads(config.SAMPLE_JSON.read_text(encoding="utf-8"))
            rides = [Ride.from_dict(r) for r in payload["rides"]]
        except (OSError, ValueError, KeyError, ValidationError) as exc:
            ui.err(f"Sample file could not be read: {exc}")
            return
        if self.store.rides:
            ui.warn(f"This REPLACES your {len(self.store.rides)} current ride(s) "
                    "(a backup copy is kept).")
            if not ui.confirm("Continue?", default=False):
                ui.info("Kept your data.")
                return
            backup = self.store.backup()
            if backup:
                ui.info(f"Backup saved: {backup.name}")
        self.store.replace_all(rides)
        ui.ok(f"Loaded {len(rides)} sample rides.")
