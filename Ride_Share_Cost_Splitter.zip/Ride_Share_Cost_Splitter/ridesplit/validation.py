"""Defensive input validation.

Every parser takes raw text (or a loosely-typed value from a file), returns a
clean, correctly typed value, or raises ValidationError with a message that is
safe to show directly to the user. Nothing in here prints or reads input.
"""

from __future__ import annotations

import re
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from typing import Iterable, Sequence

from . import config


class ValidationError(ValueError):
    """Raised when a value breaks a domain rule."""


_AMOUNT_RE = re.compile(r"^\d{1,9}(\.\d{1,2})?$")
_NAME_RE = re.compile(r"^[^\W\d_][\w .'\-]*$", re.UNICODE)
_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_CTRL_RE = re.compile(r"[\x00-\x1f\x7f]")


def clean_text(text: object) -> str:
    """Trim, collapse whitespace and strip control characters."""
    if text is None:
        return ""
    return re.sub(r"\s+", " ", _CTRL_RE.sub(" ", str(text))).strip()


def parse_amount(
    text: object,
    *,
    label: str = "Amount",
    minimum: Decimal | None = None,
    maximum: Decimal | None = None,
) -> Decimal:
    """Parse a money value: digits with at most 2 decimals, no signs/exponents."""
    if isinstance(text, Decimal):
        raw = format(text, "f")
    elif isinstance(text, float):
        raw = repr(text)
    else:
        raw = clean_text(text)
    raw = re.sub(r"^(rs\.?|inr|₹)\s*", "", raw, flags=re.IGNORECASE)
    raw = raw.replace(",", "")
    if raw == "":
        raise ValidationError(f"{label} cannot be blank.")
    if raw.startswith("-"):
        raise ValidationError(f"{label} cannot be negative.")
    if not _AMOUNT_RE.match(raw):
        # Floats like 1234.5 or 10.0 are fine; reject anything else with a reason.
        try:
            value = Decimal(raw)
        except InvalidOperation:
            raise ValidationError(f"{label} must be a number like 450 or 450.50 (got '{raw}').")
        if not value.is_finite():
            raise ValidationError(f"{label} must be a finite number.")
        if value != value.quantize(Decimal("0.01")):
            raise ValidationError(f"{label} can have at most 2 decimal places.")
        if "e" in raw.lower():
            raise ValidationError(f"{label} must be written in plain digits (no exponent).")
    value = Decimal(raw).quantize(Decimal("0.01"))
    if minimum is not None and value < minimum:
        raise ValidationError(f"{label} must be at least {minimum}.")
    if maximum is not None and value > maximum:
        raise ValidationError(f"{label} must not exceed {maximum}.")
    return value


def parse_total(text: object) -> Decimal:
    return parse_amount(
        text, label="Total fare", minimum=config.MIN_TOTAL, maximum=config.MAX_TOTAL
    )


def parse_positive_decimal(text: object, label: str, maximum: Decimal | None = None) -> Decimal:
    return parse_amount(text, label=label, minimum=Decimal("0.01"), maximum=maximum)


def parse_int(text: object, label: str, minimum: int, maximum: int) -> int:
    raw = clean_text(text)
    if not re.fullmatch(r"\d{1,6}", raw):
        raise ValidationError(f"{label} must be a whole number between {minimum} and {maximum}.")
    value = int(raw)
    if not minimum <= value <= maximum:
        raise ValidationError(f"{label} must be between {minimum} and {maximum}.")
    return value


def parse_name(text: object, taken: Iterable[str] = ()) -> str:
    name = clean_text(text)
    if not name:
        raise ValidationError("Name cannot be blank.")
    if len(name) > config.MAX_NAME_LEN:
        raise ValidationError(f"Name must be at most {config.MAX_NAME_LEN} characters.")
    if not _NAME_RE.match(name):
        raise ValidationError("Name must start with a letter and use only letters, spaces, . ' -")
    if name.casefold() in {t.casefold() for t in taken}:
        raise ValidationError(f"'{name}' is already a passenger on this ride.")
    return name


def parse_place(text: object, label: str = "Location") -> str:
    place = clean_text(text)
    if len(place) < 2:
        raise ValidationError(f"{label} must be at least 2 characters.")
    if len(place) > config.MAX_PLACE_LEN:
        raise ValidationError(f"{label} must be at most {config.MAX_PLACE_LEN} characters.")
    if not re.search(r"[^\W\d_]", place, re.UNICODE):
        raise ValidationError(f"{label} must contain at least one letter.")
    return place


def parse_date(text: object, *, allow_future: bool = False, today: date | None = None) -> str:
    """Return a normalised YYYY-MM-DD string."""
    raw = clean_text(text)
    if not _DATE_RE.match(raw):
        raise ValidationError("Date must be in YYYY-MM-DD format, e.g. 2026-11-20.")
    try:
        parsed = date.fromisoformat(raw)
    except ValueError:
        raise ValidationError(f"'{raw}' is not a real calendar date.")
    if parsed.year < config.MIN_DATE_YEAR:
        raise ValidationError(f"Date must be {config.MIN_DATE_YEAR} or later.")
    if not allow_future and parsed > (today or date.today()):
        raise ValidationError("Ride date cannot be in the future.")
    return parsed.isoformat()


def parse_due_date(text: object, ride_date: str) -> str:
    due = parse_date(text, allow_future=True)
    if due < ride_date:
        raise ValidationError("Due date cannot be before the ride date.")
    return due


def parse_choice(text: object, options: Sequence[str], label: str = "Choice") -> str:
    """Accept a 1-based number or a case-insensitive option name / unique prefix."""
    raw = clean_text(text)
    if not raw:
        raise ValidationError(f"{label} cannot be blank.")
    if raw.isdigit():
        index = int(raw)
        if 1 <= index <= len(options):
            return options[index - 1]
        raise ValidationError(f"{label} must be a number from 1 to {len(options)}.")
    matches = [o for o in options if o.casefold() == raw.casefold()]
    if not matches:
        matches = [o for o in options if o.casefold().startswith(raw.casefold())]
    if len(matches) == 1:
        return matches[0]
    raise ValidationError(f"{label} must be one of: {', '.join(options)}.")


def parse_note(text: object) -> str:
    note = clean_text(text)
    if len(note) > config.MAX_NOTE_LEN:
        raise ValidationError(f"Note must be at most {config.MAX_NOTE_LEN} characters.")
    return note


def parse_ride_id(text: object) -> str:
    raw = clean_text(text).upper()
    if not re.fullmatch(r"R\d{1,6}", raw):
        if re.fullmatch(r"\d{1,6}", raw):
            return f"R{int(raw):03d}"
        raise ValidationError("Ride ID looks like R012 (or just 12).")
    return f"R{int(raw[1:]):03d}"


def month_key(iso_date: str) -> str:
    return iso_date[:7]


def today_iso() -> str:
    return datetime.now().date().isoformat()
