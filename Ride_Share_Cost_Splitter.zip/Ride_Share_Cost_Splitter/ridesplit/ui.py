"""Terminal UI helpers: ANSI colour, banner, validated prompts, paged tables."""

from __future__ import annotations

import os
import sys
from typing import Callable, Sequence, TypeVar

from . import __version__, config
from .formatting import format_table
from .validation import ValidationError

T = TypeVar("T")

_USE_COLOR = False
CANCEL_TOKEN = "!"


class Cancelled(Exception):
    """User typed the cancel token while a prompt was open."""


# ------------------------------------------------------------------ console
def setup_console(color: bool | None = None) -> None:
    """Make output safe on any terminal (UTF-8, rupee sign fallback, ANSI on Windows)."""
    global _USE_COLOR
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")   # type: ignore[attr-defined]
        except (AttributeError, ValueError, OSError):
            pass
    encoding = (getattr(sys.stdout, "encoding", None) or "ascii")
    try:
        config.CURRENCY.encode(encoding)
    except (UnicodeEncodeError, LookupError):
        config.CURRENCY = "Rs."
    if color is None:
        color = sys.stdout.isatty() and "NO_COLOR" not in os.environ
    if color and os.name == "nt":
        os.system("")          # enables ANSI escape processing on Windows 10+
    _USE_COLOR = bool(color)


_CODES = {"bold": "1", "dim": "2", "red": "31", "green": "32", "yellow": "33",
          "blue": "34", "magenta": "35", "cyan": "36"}


def c(text: object, *styles: str) -> str:
    text = str(text)
    if not _USE_COLOR or not styles:
        return text
    codes = ";".join(_CODES[s] for s in styles)
    return f"\033[{codes}m{text}\033[0m"


# ---------------------------------------------------------------- messaging
def ok(msg: str) -> None:
    print(c("[OK] ", "green", "bold") + msg)


def err(msg: str) -> None:
    print(c("[X] ", "red", "bold") + msg)


def warn(msg: str) -> None:
    print(c("[!] ", "yellow", "bold") + msg)


def info(msg: str) -> None:
    print(c("[i] ", "cyan") + msg)


def heading(title: str) -> None:
    print()
    print(c(f"== {title} ", "bold", "cyan") + c("=" * max(4, 60 - len(title)), "cyan"))


def banner() -> None:
    art = [
        r"  ____  _     _      ____        _ _ _   ",
        r" |  _ \(_) __| | ___/ ___| _ __ | (_) |_ ",
        r" | |_) | |/ _` |/ _ \___ \| '_ \| | | __|",
        r" |  _ <| | (_| |  __/___) | |_) | | | |_ ",
        r" |_| \_\_|\__,_|\___|____/| .__/|_|_|\__|",
        r"                          |_|            ",
    ]
    print()
    for line in art:
        print(c(line, "cyan", "bold"))
    print(c(f"  Ride Share Cost Splitter  v{__version__}", "bold"))
    print(c("  Split any ride fairly - equal or unequal - to the last paisa.", "dim"))
    print()


# ------------------------------------------------------------------ prompts
def ask(
    prompt: str,
    parser: Callable[[str], T],
    *,
    default: str | None = None,
    allow_blank: bool = False,
    hint: str = "",
) -> T | None:
    """Loop until `parser` accepts the input. Returns None if blank is allowed.

    Typing '!' cancels the whole operation (raises Cancelled). EOFError is left to
    propagate so the main loop can exit cleanly when stdin is closed.
    """
    suffix = ""
    if default is not None:
        suffix = f" [{default}]"
    elif allow_blank:
        suffix = " [blank to skip]"
    if hint:
        suffix += f" ({hint})"
    while True:
        raw = input(f"{prompt}{suffix}: ").strip()
        if raw == CANCEL_TOKEN:
            raise Cancelled()
        if raw == "":
            if default is not None:
                raw = default
            elif allow_blank:
                return None
        try:
            return parser(raw)
        except ValidationError as exc:
            err(str(exc))


def confirm(prompt: str, default: bool | None = None) -> bool:
    hint = {True: "Y/n", False: "y/N", None: "y/n"}[default]
    while True:
        raw = input(f"{prompt} [{hint}]: ").strip().lower()
        if raw == CANCEL_TOKEN:
            raise Cancelled()
        if raw in ("y", "yes"):
            return True
        if raw in ("n", "no"):
            return False
        if raw == "" and default is not None:
            return default
        err("Please answer y or n.")


def choose(title: str, options: Sequence[str]) -> str:
    """Numbered pick-list; returns the chosen option."""
    from .validation import parse_choice
    for i, opt in enumerate(options, 1):
        print(f"   {c(i, 'bold')}. {opt}")
    return ask(title, lambda t: parse_choice(t, options, title))  # type: ignore[return-value]


# ------------------------------------------------------------------- tables
def print_table(headers, rows, aligns=None, max_width=26, style=None) -> None:
    for line in format_table(headers, rows, aligns, max_width, style):
        print(line)


def paged_table(headers, rows, aligns=None, page_size=config.PAGE_SIZE,
                max_width=26, style=None) -> None:
    """Show rows page by page (n = next, p = previous, q = stop)."""
    if not rows:
        info("Nothing to show.")
        return
    pages = (len(rows) + page_size - 1) // page_size
    page = 0
    while True:
        chunk = rows[page * page_size:(page + 1) * page_size]
        offset = page * page_size
        shifted = (lambda r, col, text: style(r + offset, col, text)) if style else None
        print_table(headers, chunk, aligns, max_width, shifted)
        print(c(f"  Page {page + 1}/{pages} - rows {offset + 1}-{offset + len(chunk)} of {len(rows)}", "dim"))
        if pages == 1:
            return
        nav = input("  [n]ext  [p]revious  [q]uit paging: ").strip().lower()
        if nav in ("n", "next", "") and page < pages - 1:
            page += 1
        elif nav in ("p", "prev", "previous") and page > 0:
            page -= 1
        elif nav in ("q", "quit", CANCEL_TOKEN):
            return
        elif nav in ("n", "next", ""):
            return              # already at last page
        else:
            err("Use n, p or q.")


def pause() -> None:
    input(c("\nPress Enter to return to the menu...", "dim"))
