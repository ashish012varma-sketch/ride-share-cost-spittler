"""Core business logic: divide a shared ride cost among passengers.

All maths is done in integer paise/cents (and exact Fractions for weights), so
shares ALWAYS add up to the total to the last paisa. Leftover paise are handed
out with the "largest remainder" method; ties go to the earlier passenger.
"""

from __future__ import annotations

from decimal import Decimal
from fractions import Fraction
from typing import Sequence

from . import config
from .validation import ValidationError

CENT = Decimal("0.01")


def to_cents(amount: Decimal) -> int:
    return int((amount * 100).to_integral_value())


def from_cents(cents: int) -> Decimal:
    return (Decimal(cents) / 100).quantize(CENT)


def _largest_remainder(total_cents: int, weights: Sequence[Fraction]) -> list[int]:
    weight_sum = sum(weights)
    if weight_sum <= 0:
        raise ValidationError("Weights must add up to more than zero.")
    exact = [Fraction(total_cents) * w / weight_sum for w in weights]
    floors = [x.numerator // x.denominator for x in exact]
    leftover = total_cents - sum(floors)
    order = sorted(range(len(weights)), key=lambda i: (-(exact[i] - floors[i]), i))
    for i in order[:leftover]:
        floors[i] += 1
    return floors


def split_equal(total: Decimal, count: int) -> list[Decimal]:
    if count < 1:
        raise ValidationError("At least one passenger is required.")
    cents = _largest_remainder(to_cents(total), [Fraction(1)] * count)
    return [from_cents(c) for c in cents]


def split_weighted(total: Decimal, weights: Sequence[Decimal]) -> list[Decimal]:
    if not weights:
        raise ValidationError("At least one passenger is required.")
    if any(w <= 0 for w in weights):
        raise ValidationError("Every weight must be greater than zero.")
    cents = _largest_remainder(to_cents(total), [Fraction(w) for w in weights])
    return [from_cents(c) for c in cents]


def split_percent(total: Decimal, percents: Sequence[Decimal]) -> list[Decimal]:
    if any(p <= 0 for p in percents):
        raise ValidationError("Every percentage must be greater than zero.")
    pct_sum = sum(percents)
    if pct_sum != Decimal("100"):
        raise ValidationError(f"Percentages must add up to exactly 100 (currently {pct_sum}).")
    return split_weighted(total, percents)


def split_exact(total: Decimal, amounts: Sequence[Decimal]) -> list[Decimal]:
    if any(a <= 0 for a in amounts):
        raise ValidationError("Every share must be greater than zero.")
    diff = total - sum(amounts)
    if diff != 0:
        word = "short" if diff > 0 else "over"
        raise ValidationError(
            f"Shares must add up to {total} - they are {abs(diff)} {word}."
        )
    return [a.quantize(CENT) for a in amounts]


def compute_shares(
    total: Decimal, method: str, count: int, values: Sequence[Decimal] | None = None
) -> list[Decimal]:
    """Return one share per passenger for the chosen split method."""
    if method not in config.METHODS:
        raise ValidationError(f"Unknown split method '{method}'.")
    if method == "equal":
        return split_equal(total, count)
    if values is None or len(values) != count:
        raise ValidationError(f"A value is needed for each of the {count} passengers.")
    if method == "percent":
        return split_percent(total, values)
    if method == "exact":
        return split_exact(total, values)
    return split_weighted(total, values)


def remaining(total: Decimal, entered: Sequence[Decimal]) -> Decimal:
    """What is left to allocate (used to auto-fill the last passenger)."""
    return total - sum(entered, Decimal("0"))
